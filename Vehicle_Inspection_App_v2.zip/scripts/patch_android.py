import re, shutil, sys

PKG = 'com.inspect.vehicleform'

# ---- AndroidManifest: login redirect + camera permission ----
mf = 'android/app/src/main/AndroidManifest.xml'
s = open(mf, encoding='utf-8').read()
if 'oauth2redirect-filter' not in s:
    flt = f'''
        <!-- oauth2redirect-filter -->
        <intent-filter>
            <action android:name="android.intent.action.VIEW" />
            <category android:name="android.intent.category.DEFAULT" />
            <category android:name="android.intent.category.BROWSABLE" />
            <data android:scheme="{PKG}" />
        </intent-filter>
    '''
    s = re.sub(r'<activity(?![^>]*screenOrientation)', '<activity android:screenOrientation="portrait"', s, count=1)
    i = s.find('</activity>')
    if i < 0:
        sys.exit('patch: </activity> not found in AndroidManifest.xml')
    s = s[:i] + flt + s[i:]
    perms = ('    <uses-permission android:name="android.permission.CAMERA" />\n'
             '    <uses-feature android:name="android.hardware.camera" android:required="false" />\n')
    s = s.replace('</manifest>', perms + '</manifest>')
    open(mf, 'w', encoding='utf-8').write(s)
    print('patched manifest')

# ---- Gradle: fixed signing key so the APK signature never changes ----
gp = 'android/app/build.gradle'
g = open(gp, encoding='utf-8').read()
if 'signingConfigs.release' not in g:
    shutil.copy('release.p12', 'android/release.p12')
    sc = '''    signingConfigs {
        release {
            storeFile file("../release.p12")
            storePassword "inspect123"
            keyAlias "inspect"
            keyPassword "inspect123"
            storeType "pkcs12"
        }
    }
'''
    m = re.search(r'\n([ \t]*)buildTypes\s*\{\s*release\s*\{', g)
    if not m:
        sys.exit('patch: buildTypes { release { not found in app/build.gradle')
    g = g[:m.start() + 1] + sc + g[m.start() + 1:]
    g = re.sub(r'(buildTypes\s*\{\s*release\s*\{)', r'\1\n            signingConfig signingConfigs.release', g, count=1)
    open(gp, 'w', encoding='utf-8').write(g)
    print('patched gradle')
