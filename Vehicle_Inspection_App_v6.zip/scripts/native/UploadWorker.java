package com.inspect.vehicleform;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.os.Build;

import androidx.annotation.NonNull;
import androidx.core.app.NotificationCompat;
import androidx.work.BackoffPolicy;
import androidx.work.Constraints;
import androidx.work.ExistingWorkPolicy;
import androidx.work.ForegroundInfo;
import androidx.work.NetworkType;
import androidx.work.OneTimeWorkRequest;
import androidx.work.OutOfQuotaPolicy;
import androidx.work.WorkManager;
import androidx.work.Worker;
import androidx.work.WorkerParameters;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.TimeUnit;

/**
 * Uploads queued inspection jobs (photos -> Drive folder, row -> Google Sheet) in the background.
 * Job layout: files/jobs/<id>/job.json + p000.jpg, p001.jpg ...
 */
public class UploadWorker extends Worker {

    static final String UNIQUE = "vif-upload";
    static final String CHANNEL = "vif_upload";
    static final int NOTIF_ID = 4711;

    public UploadWorker(@NonNull Context context, @NonNull WorkerParameters params) {
        super(context, params);
    }

    // ---------- shared helpers ----------
    static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences("vif_native", Context.MODE_PRIVATE);
    }

    static File jobsDir(Context c) {
        File d = new File(c.getFilesDir(), "jobs");
        if (!d.exists()) d.mkdirs();
        return d;
    }

    /** committed jobs only (a directory without job.json is still being staged), oldest first */
    static List<File> pendingJobs(Context c) {
        List<File> out = new ArrayList<>();
        File[] dirs = jobsDir(c).listFiles();
        if (dirs == null) return out;
        for (File d : dirs) {
            if (d.isDirectory() && new File(d, "job.json").exists()) out.add(d);
        }
        Collections.sort(out, (a, b) -> {
            try { return Long.compare(Long.parseLong(a.getName()), Long.parseLong(b.getName())); }
            catch (NumberFormatException e) { return a.getName().compareTo(b.getName()); }
        });
        return out;
    }

    static void writeAtomic(File f, byte[] bytes) throws IOException {
        File tmp = new File(f.getParentFile(), f.getName() + ".tmp");
        try (FileOutputStream o = new FileOutputStream(tmp)) { o.write(bytes); o.getFD().sync(); }
        if (!tmp.renameTo(f)) {
            if (f.exists()) f.delete();
            if (!tmp.renameTo(f)) throw new IOException("rename failed");
        }
    }

    static void deleteDir(File d) {
        File[] kids = d.listFiles();
        if (kids != null) for (File k : kids) { if (k.isDirectory()) deleteDir(k); else k.delete(); }
        d.delete();
    }

    static byte[] readFile(File f) throws IOException {
        try (InputStream in = new FileInputStream(f)) { return readBytes(in); }
    }

    static byte[] readBytes(InputStream in) throws IOException {
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        byte[] buf = new byte[16384];
        int n;
        while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
        return bo.toByteArray();
    }

    static void schedule(Context c, boolean replace) {
        if (pendingJobs(c).isEmpty()) return;
        Constraints cons = new Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build();
        OneTimeWorkRequest req = new OneTimeWorkRequest.Builder(UploadWorker.class)
                .setConstraints(cons)
                .setExpedited(OutOfQuotaPolicy.RUN_AS_NON_EXPEDITED_WORK_REQUEST)
                .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 30, TimeUnit.SECONDS)
                .build();
        WorkManager.getInstance(c).enqueueUniqueWork(UNIQUE,
                replace ? ExistingWorkPolicy.REPLACE : ExistingWorkPolicy.KEEP, req);
    }

    private void progress(SharedPreferences sp, String text) {
        sp.edit().putString("progress", text).putLong("progressTs", System.currentTimeMillis()).apply();
    }

    // ---------- foreground info (needed for expedited work on Android < 12) ----------
    @NonNull
    @Override
    public ForegroundInfo getForegroundInfo() {
        Context c = getApplicationContext();
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel(CHANNEL, "ส่งรูปตรวจสภาพรถ", NotificationManager.IMPORTANCE_LOW);
            NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm != null) nm.createNotificationChannel(ch);
        }
        Notification n = new NotificationCompat.Builder(c, CHANNEL)
                .setContentTitle("กำลังส่งรูปตรวจสภาพรถ")
                .setContentText("กำลังส่งขึ้น Google Drive / Sheet เบื้องหลัง")
                .setSmallIcon(android.R.drawable.stat_sys_upload)
                .setOngoing(true)
                .build();
        if (Build.VERSION.SDK_INT >= 29) {
            return new ForegroundInfo(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC);
        }
        return new ForegroundInfo(NOTIF_ID, n);
    }

    // ---------- main work ----------
    @NonNull
    @Override
    public Result doWork() {
        Context c = getApplicationContext();
        SharedPreferences sp = prefs(c);
        if (pendingJobs(c).isEmpty()) return Result.success();

        String clientId = sp.getString("clientId", "");
        String refresh = sp.getString("refresh", "");
        String sheetId = sp.getString("sheetId", "");
        if (clientId.isEmpty() || refresh.isEmpty() || sheetId.isEmpty()) {
            sp.edit().putString("err", "AUTH:ยังไม่ได้ล็อกอิน Google").apply();
            return Result.failure();
        }
        try {
            progress(sp, "เริ่มส่ง...");
            Api api = new Api(clientId, refresh);
            while (!isStopped()) {
                List<File> jobs = pendingJobs(c);
                if (jobs.isEmpty()) break;
                processJob(api, jobs.get(0), sheetId, sp);
            }
            if (isStopped()) return Result.retry();
            sp.edit().remove("err").apply();
            return Result.success();
        } catch (AuthException e) {
            sp.edit().putString("err", "AUTH:" + e.getMessage()).apply();
            return Result.failure();
        } catch (HttpException e) {
            String m = String.valueOf(e.getMessage());
            boolean transientErr = e.code == 429 || e.code >= 500 || m.contains("ateLimit");
            sp.edit().putString("err", (transientErr ? "NET:" : "HTTP:") + m).apply();
            return transientErr ? Result.retry() : Result.failure();
        } catch (IOException e) {
            sp.edit().putString("err", "NET:" + e.getClass().getSimpleName()).apply();
            return Result.retry();
        } catch (Exception e) {
            sp.edit().putString("err", "HTTP:" + e.getClass().getSimpleName() + " " + e.getMessage()).apply();
            return Result.failure();
        } finally {
            sp.edit().remove("progress").apply();
        }
    }

    private void processJob(Api api, File dir, String sheetId, SharedPreferences sp) throws Exception {
        File jf = new File(dir, "job.json");
        JSONObject job = new JSONObject(new String(readFile(jf), StandardCharsets.UTF_8));
        JSONArray names = job.getJSONArray("fileNames");
        JSONArray row = job.getJSONArray("row");
        String label = row.length() > 2 ? row.optString(2, "") : "";
        int total = names.length();

        String folderId = job.optString("folderId", "");
        if (folderId.isEmpty()) {
            progress(sp, label + ": เตรียมโฟลเดอร์");
            String rootName = sp.getString("rootName", "Vehicle Inspection Photos");
            String[] root = api.findOrCreate(rootName, null);
            String[] car = api.findOrCreate(job.getString("folderName"), root[0]);
            job.put("folderId", car[0]);
            job.put("folderLink", car[1]);
            writeAtomic(jf, job.toString().getBytes(StandardCharsets.UTF_8));
            folderId = car[0];
        }

        for (int i = job.optInt("uploaded", 0); i < total; i++) {
            if (isStopped()) return;
            progress(sp, label + ": อัปโหลดรูป " + (i + 1) + "/" + total);
            File f = new File(dir, String.format(Locale.US, "p%03d.jpg", i));
            if (!f.exists()) throw new HttpException(0, "ไฟล์รูปหาย " + f.getName());
            api.uploadJpeg(names.getString(i), folderId, f);
            job.put("uploaded", i + 1);
            writeAtomic(jf, job.toString().getBytes(StandardCharsets.UTF_8));
            f.delete();
        }

        if (!job.optBoolean("rowDone", false)) {
            progress(sp, label + ": บันทึกลงชีท");
            JSONArray full = new JSONArray();
            for (int i = 0; i < row.length(); i++) full.put(row.get(i));
            full.put(job.optString("folderLink", ""));
            api.appendRow(sp, sheetId, job.getJSONArray("header"), full);
            job.put("rowDone", true);
            writeAtomic(jf, job.toString().getBytes(StandardCharsets.UTF_8));
        }
        deleteDir(dir);
    }

    // ---------- errors ----------
    static class AuthException extends Exception {
        AuthException(String m) { super(m); }
    }

    static class HttpException extends Exception {
        final int code;
        HttpException(int code, String m) { super(m); this.code = code; }
    }

    // ---------- Google REST (HttpURLConnection, no extra libraries) ----------
    static class Api {
        final String clientId, refresh;
        String access;
        long exp;

        Api(String clientId, String refresh) {
            this.clientId = clientId;
            this.refresh = refresh;
        }

        static HttpURLConnection open(String url, String method) throws IOException {
            HttpURLConnection h = (HttpURLConnection) new URL(url).openConnection();
            h.setRequestMethod(method);
            h.setConnectTimeout(20000);
            h.setReadTimeout(90000);
            return h;
        }

        static String body(HttpURLConnection h, int code) throws IOException {
            InputStream in = code >= 400 ? h.getErrorStream() : h.getInputStream();
            return in == null ? "" : new String(readBytes(in), StandardCharsets.UTF_8);
        }

        void refreshAccess() throws Exception {
            byte[] b = ("grant_type=refresh_token&refresh_token=" + URLEncoder.encode(refresh, "UTF-8")
                    + "&client_id=" + URLEncoder.encode(clientId, "UTF-8")).getBytes(StandardCharsets.UTF_8);
            HttpURLConnection h = open("https://oauth2.googleapis.com/token", "POST");
            h.setDoOutput(true);
            h.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
            h.setFixedLengthStreamingMode(b.length);
            try (OutputStream o = h.getOutputStream()) { o.write(b); }
            int code = h.getResponseCode();
            String resp = body(h, code);
            h.disconnect();
            if (code >= 400) {
                if (resp.contains("invalid_grant") || resp.contains("invalid_client") || resp.contains("unauthorized_client")) {
                    throw new AuthException("ต้องล็อกอิน Google ใหม่");
                }
                throw new HttpException(code, "token " + code);
            }
            JSONObject j = new JSONObject(resp);
            access = j.getString("access_token");
            exp = System.currentTimeMillis() + j.optLong("expires_in", 3600) * 1000L;
        }

        String call(String method, String url, String ctype, byte[] payload) throws Exception {
            for (int attempt = 0; attempt < 2; attempt++) {
                if (access == null || System.currentTimeMillis() > exp - 60000) refreshAccess();
                HttpURLConnection h = open(url, method);
                h.setRequestProperty("Authorization", "Bearer " + access);
                if (ctype != null) h.setRequestProperty("Content-Type", ctype);
                if (payload != null) {
                    h.setDoOutput(true);
                    h.setFixedLengthStreamingMode(payload.length);
                    try (OutputStream o = h.getOutputStream()) { o.write(payload); }
                }
                int code = h.getResponseCode();
                String resp = body(h, code);
                h.disconnect();
                if (code == 401) {
                    if (attempt == 0) { access = null; continue; }
                    throw new AuthException("ต้องล็อกอิน Google ใหม่");
                }
                if (code >= 400) {
                    throw new HttpException(code, code + " " + (resp.length() > 160 ? resp.substring(0, 160) : resp));
                }
                return resp;
            }
            throw new HttpException(0, "unreachable");
        }

        String[] findOrCreate(String name, String parent) throws Exception {
            String esc = name.replace("\\", "\\\\").replace("'", "\\'");
            String q = "name='" + esc + "' and mimeType='application/vnd.google-apps.folder' and trashed=false";
            if (parent != null) q += " and '" + parent + "' in parents";
            String r = call("GET", "https://www.googleapis.com/drive/v3/files?fields="
                    + URLEncoder.encode("files(id,webViewLink)", "UTF-8") + "&q=" + URLEncoder.encode(q, "UTF-8"), null, null);
            JSONArray a = new JSONObject(r).optJSONArray("files");
            if (a != null && a.length() > 0) {
                JSONObject f = a.getJSONObject(0);
                return new String[]{f.getString("id"), f.optString("webViewLink", "")};
            }
            JSONObject b = new JSONObject();
            b.put("name", name);
            b.put("mimeType", "application/vnd.google-apps.folder");
            if (parent != null) b.put("parents", new JSONArray().put(parent));
            String c = call("POST", "https://www.googleapis.com/drive/v3/files?fields="
                    + URLEncoder.encode("id,webViewLink", "UTF-8"), "application/json; charset=UTF-8",
                    b.toString().getBytes(StandardCharsets.UTF_8));
            JSONObject f = new JSONObject(c);
            return new String[]{f.getString("id"), f.optString("webViewLink", "")};
        }

        void uploadJpeg(String name, String folderId, File file) throws Exception {
            byte[] img = readFile(file);
            String boundary = "vif" + System.nanoTime();
            JSONObject meta = new JSONObject();
            meta.put("name", name);
            meta.put("parents", new JSONArray().put(folderId));
            ByteArrayOutputStream bo = new ByteArrayOutputStream(img.length + 1024);
            bo.write(("--" + boundary + "\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n").getBytes(StandardCharsets.UTF_8));
            bo.write(meta.toString().getBytes(StandardCharsets.UTF_8));
            bo.write(("\r\n--" + boundary + "\r\nContent-Type: image/jpeg\r\n\r\n").getBytes(StandardCharsets.UTF_8));
            bo.write(img);
            bo.write(("\r\n--" + boundary + "--").getBytes(StandardCharsets.UTF_8));
            call("POST", "https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart&fields=id",
                    "multipart/related; boundary=" + boundary, bo.toByteArray());
        }

        String sheetTitle(SharedPreferences sp, String sheetId) throws Exception {
            String t = sp.getString("sheetTitle", "");
            if (!t.isEmpty() && sheetId.equals(sp.getString("sheetFor", ""))) return t;
            String r = call("GET", "https://sheets.googleapis.com/v4/spreadsheets/" + sheetId + "?fields="
                    + URLEncoder.encode("sheets.properties.title", "UTF-8"), null, null);
            t = new JSONObject(r).getJSONArray("sheets").getJSONObject(0).getJSONObject("properties").getString("title");
            sp.edit().putString("sheetTitle", t).putString("sheetFor", sheetId).apply();
            return t;
        }

        void appendRow(SharedPreferences sp, String sheetId, JSONArray header, JSONArray row) throws Exception {
            String t = sheetTitle(sp, sheetId);
            String rng = URLEncoder.encode("'" + t.replace("'", "''") + "'!A1", "UTF-8").replace("+", "%20");
            String base = "https://sheets.googleapis.com/v4/spreadsheets/" + sheetId + "/values/" + rng;
            try {
                String h = call("GET", base, null, null);
                JSONArray values = new JSONArray();
                if (!new JSONObject(h).has("values")) values.put(header);
                values.put(row);
                JSONObject body = new JSONObject();
                body.put("values", values);
                call("POST", base + ":append?valueInputOption=USER_ENTERED&insertDataOption=INSERT_ROWS",
                        "application/json; charset=UTF-8", body.toString().getBytes(StandardCharsets.UTF_8));
            } catch (HttpException e) {
                if (e.code == 400) sp.edit().remove("sheetTitle").remove("sheetFor").apply();   // tab renamed?
                throw e;
            }
        }
    }
}
