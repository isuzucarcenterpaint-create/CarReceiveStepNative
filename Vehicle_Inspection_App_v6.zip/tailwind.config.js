module.exports = {
  darkMode: 'class',
  content: ['./www/index.html'],
  theme: {
    extend: {
      fontFamily: { sans: ['Prompt', 'sans-serif'] },
      colors: {
        brand: { 50: '#fff7ed', 100: '#ffedd5', 500: '#ff6b00', 600: '#ea580c', 700: '#c2410c' },
        darkbg: '#0d1117', darkcard: '#161b22', darkborder: '#30363d', darkinput: '#21262d'
      }
    }
  }
};
