package com.mycompany.carreceivestep2

import android.Manifest
import android.content.ClipData
import android.content.ContentValues
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.drawable.GradientDrawable
import android.media.ExifInterface
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.widget.FrameLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import android.util.Size
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.core.resolutionselector.ResolutionSelector
import androidx.camera.core.resolutionselector.ResolutionStrategy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import java.io.ByteArrayOutputStream
import java.util.concurrent.Executors
import kotlin.math.max
import kotlin.math.min

class BurstCameraActivity : ComponentActivity() {

    private lateinit var previewView: PreviewView
    private lateinit var countText: TextView
    private var imageCapture: ImageCapture? = null
    private val saved = ArrayList<Uri>()
    private val worker = Executors.newSingleThreadExecutor()
    private var holding = false
    private var capturing = false
    private var closing = false
    private var delivered = false

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() = finishWithResult()
        })

        if (checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            startCamera()
        } else {
            requestPermissions(arrayOf(Manifest.permission.CAMERA), 1)
        }
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<String>, results: IntArray) {
        super.onRequestPermissionsResult(code, perms, results)
        if (results.isNotEmpty() && results[0] == PackageManager.PERMISSION_GRANTED) {
            startCamera()
        } else {
            Toast.makeText(this, "ต้องอนุญาตการใช้กล้อง", Toast.LENGTH_LONG).show()
            setResult(RESULT_CANCELED)
            finish()
        }
    }

    private fun buildUi() {
        val root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }

        previewView = PreviewView(this)
        root.addView(previewView, FrameLayout.LayoutParams(-1, -1))

        countText = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 18f
            text = "0 รูป"
            setPadding(dp(16), dp(8), dp(16), dp(8))
            background = GradientDrawable().apply {
                cornerRadius = dp(20).toFloat()
                setColor(0x99000000.toInt())
            }
        }
        root.addView(countText, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply {
            topMargin = dp(40)
        })

        val hint = TextView(this).apply {
            setTextColor(0xCCFFFFFF.toInt())
            textSize = 13f
            text = "แตะ = ถ่าย 1 รูป   กดค้าง = ถ่ายรัว"
        }
        root.addView(hint, FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply {
            bottomMargin = dp(130)
        })

        val shutter = View(this).apply {
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.WHITE)
                setStroke(dp(5), 0x66FFFFFF)
            }
        }
        shutter.setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    holding = true
                    v.animate().scaleX(0.88f).scaleY(0.88f).setDuration(80).start()
                    shoot()
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    holding = false
                    v.animate().scaleX(1f).scaleY(1f).setDuration(80).start()
                }
            }
            true
        }
        root.addView(shutter, FrameLayout.LayoutParams(dp(78), dp(78), Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply {
            bottomMargin = dp(40)
        })

        val done = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 18f
            text = "เสร็จสิ้น"
            setPadding(dp(16), dp(12), dp(16), dp(12))
            setOnClickListener { finishWithResult() }
        }
        root.addView(done, FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.END).apply {
            bottomMargin = dp(52); marginEnd = dp(16)
        })

        val cancel = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 18f
            text = "ยกเลิก"
            setPadding(dp(16), dp(12), dp(16), dp(12))
            setOnClickListener {
                if (closing) return@setOnClickListener
                closing = true
                delivered = true
                holding = false
                val list = ArrayList(saved)
                saved.clear()
                worker.execute {
                    list.forEach { runCatching { contentResolver.delete(it, null, null) } }
                    runOnUiThread {
                        setResult(RESULT_CANCELED)
                        finish()
                    }
                }
            }
        }
        root.addView(cancel, FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.START).apply {
            bottomMargin = dp(52); marginStart = dp(16)
        })

        setContentView(root)
    }

    private fun startCamera() {
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            val provider = future.get()
            val preview = Preview.Builder().build().also { it.setSurfaceProvider(previewView.surfaceProvider) }
            // ถ่ายที่ความละเอียด/คุณภาพต่ำลงตั้งแต่ต้น เพื่อให้ไฟล์ส่วนใหญ่เล็กพอ (≤200KB) อยู่แล้วโดยไม่ต้องบีบอัดซ้ำทีหลัง
            val resolutionSelector = ResolutionSelector.Builder()
                .setResolutionStrategy(
                    ResolutionStrategy(Size(1600, 1200), ResolutionStrategy.FALLBACK_RULE_CLOSEST_LOWER_THEN_HIGHER)
                )
                .build()
            val capture = ImageCapture.Builder()
                .setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY)
                .setResolutionSelector(resolutionSelector)
                .setJpegQuality(65)
                .build()
            imageCapture = capture
            try {
                provider.unbindAll()
                provider.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, preview, capture)
            } catch (e: Exception) {
                Toast.makeText(this, "เปิดกล้องไม่ได้: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun shoot() {
        val ic = imageCapture ?: return
        if (capturing || closing) return
        capturing = true

        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, "CAR_${System.currentTimeMillis()}_${saved.size + 1}")
            put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
            put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/CarReceiveStep")
        }
        val options = ImageCapture.OutputFileOptions.Builder(
            contentResolver, MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values
        ).build()

        ic.takePicture(options, ContextCompat.getMainExecutor(this),
            object : ImageCapture.OnImageSavedCallback {
                override fun onImageSaved(result: ImageCapture.OutputFileResults) {
                    capturing = false
                    result.savedUri?.let { uri ->
                        saved.add(uri)
                        worker.execute { compressTo200Kb(uri) } // บีบอัดเบื้องหลัง ไม่ขัดจังหวะการถ่ายรัว
                    }
                    countText.text = "${saved.size} รูป"
                    previewView.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                    if (closing) startDeliver() else if (holding) shoot()
                }

                override fun onError(exception: ImageCaptureException) {
                    capturing = false
                    holding = false
                    Toast.makeText(this@BurstCameraActivity, "ถ่ายไม่สำเร็จ: ${exception.message}", Toast.LENGTH_SHORT).show()
                    if (closing) startDeliver()
                }
            })
    }

    // บีบอัดรูปให้ไม่เกิน 200 KB (ลดขนาด + ลดคุณภาพ) แล้วเขียนทับไฟล์เดิม
    // ตอนนี้ถ่ายมาเล็ก/คุณภาพต่ำตั้งแต่ต้นแล้ว (ดู startCamera) ฟังก์ชันนี้จึงเป็นแค่ "ตัวสำรอง"
    // ที่ทำงานเฉพาะรูปที่ยังเกิน 200KB หรือมี EXIF ต้องหมุนเท่านั้น รูปส่วนใหญ่จะข้ามขั้นตอนนี้ไปเลย ทำให้ส่งไฟล์ให้เว็บได้เร็วขึ้น
    private fun compressTo200Kb(uri: Uri) {
        try {
            val maxBytes = 200 * 1024

            val currentSize = runCatching {
                contentResolver.openAssetFileDescriptor(uri, "r")?.use { it.length }
            }.getOrNull() ?: -1L

            val orientation = contentResolver.openInputStream(uri)?.use {
                ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
            } ?: ExifInterface.ORIENTATION_NORMAL
            val degrees = when (orientation) {
                ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                else -> 0f
            }

            // ไฟล์เล็กพอและไม่ต้องหมุนอยู่แล้ว -> ไม่ต้องเปิด bitmap มาประมวลผลซ้ำเลย
            if (degrees == 0f && currentSize in 1..maxBytes.toLong()) return

            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            val longSide = max(bounds.outWidth, bounds.outHeight)
            var sample = 1
            while (longSide / sample > 2400) sample *= 2

            val opts = BitmapFactory.Options().apply { inSampleSize = sample }
            var bmp = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) } ?: return

            if (degrees != 0f) {
                val m = Matrix().apply { postRotate(degrees) }
                val rotated = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
                if (rotated !== bmp) bmp.recycle()
                bmp = rotated
            }

            val w = bmp.width
            val h = bmp.height
            var scale = min(1f, 1600f / max(w, h))
            var out: ByteArray? = null
            while (true) {
                val b = if (scale < 1f) {
                    Bitmap.createScaledBitmap(bmp, max(1, (w * scale).toInt()), max(1, (h * scale).toInt()), true)
                } else bmp
                var q = 85
                var data = encode(b, q)
                while (data.size > maxBytes && q > 45) {
                    q -= 10
                    data = encode(b, q)
                }
                if (b !== bmp) b.recycle()
                if (data.size <= maxBytes || scale < 0.2f) {
                    out = data
                    break
                }
                scale *= 0.85f
            }
            bmp.recycle()

            val bytes = out ?: return
            contentResolver.openOutputStream(uri, "wt")?.use { it.write(bytes) }
        } catch (e: Exception) {
            // ถ้าบีบอัดไม่สำเร็จ ปล่อยไฟล์เดิมไว้
        }
    }

    private fun encode(b: Bitmap, q: Int): ByteArray {
        val bos = ByteArrayOutputStream()
        b.compress(Bitmap.CompressFormat.JPEG, q, bos)
        return bos.toByteArray()
    }

    private fun finishWithResult() {
        holding = false
        if (closing) return
        closing = true
        countText.text = "กำลังบีบอัดรูป…"
        if (!capturing) startDeliver()
    }

    // งานของ worker ทำเรียงคิว จึงรอให้บีบอัดครบทุกรูปก่อนแล้วค่อยส่งกลับ
    private fun startDeliver() {
        if (delivered) return
        delivered = true
        worker.execute { runOnUiThread { deliver() } }
    }

    private fun deliver() {
        if (saved.isEmpty()) {
            setResult(RESULT_CANCELED)
        } else {
            val clip = ClipData.newRawUri("photos", saved[0])
            for (i in 1 until saved.size) clip.addItem(ClipData.Item(saved[i]))
            val data = Intent().apply {
                this.clipData = clip
                this.data = saved[0]
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            setResult(RESULT_OK, data)
        }
        finish()
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        previewView.display?.let { imageCapture?.targetRotation = it.rotation }
    }

    override fun onDestroy() {
        worker.shutdown()
        super.onDestroy()
    }
}
