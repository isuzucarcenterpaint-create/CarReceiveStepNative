package com.mycompany.carreceivestep2

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager

// Foreground service กันระบบฆ่าแอประหว่างกำลังส่งรูป/ข้อมูลค้างอยู่ (ให้ส่งต่อได้แม้ล็อกหน้าจอ)
class KeepAliveService : Service() {

    companion object {
        private const val CHANNEL = "keepalive"
        private const val NOTIF_ID = 1
        private const val ACTION_STOP = "com.mycompany.carreceivestep.STOP"

        @Volatile var running = false

        fun start(ctx: Context) {
            try {
                ctx.startForegroundService(Intent(ctx, KeepAliveService::class.java))
            } catch (e: Exception) {
            }
        }

        fun stop(ctx: Context) {
            ctx.stopService(Intent(ctx, KeepAliveService::class.java))
        }

        fun onPendingChanged(ctx: Context, n: Int) {
            if (n == 0) {
                stop(ctx)
            } else if (running) {
                ctx.getSystemService(NotificationManager::class.java).notify(NOTIF_ID, build(ctx, n))
            } else {
                start(ctx)
            }
        }

        private fun build(ctx: Context, pending: Int): Notification {
            val nm = ctx.getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL, "ทำงานเบื้องหลัง", NotificationManager.IMPORTANCE_LOW)
            )
            val open = PendingIntent.getActivity(
                ctx, 0,
                Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            val stopPi = PendingIntent.getService(
                ctx, 1,
                Intent(ctx, KeepAliveService::class.java).setAction(ACTION_STOP),
                PendingIntent.FLAG_IMMUTABLE
            )
            val text = if (pending > 0) "เหลือ $pending รายการ กำลังส่ง…" else "กำลังทำงานเบื้องหลัง"
            val stopAction = Notification.Action.Builder(
                Icon.createWithResource(ctx, android.R.drawable.ic_menu_close_clear_cancel),
                "หยุด", stopPi
            ).build()
            return Notification.Builder(ctx, CHANNEL)
                .setSmallIcon(android.R.drawable.stat_sys_upload)
                .setContentTitle("CarReceiveStep")
                .setContentText(text)
                .setContentIntent(open)
                .addAction(stopAction)
                .setOngoing(true)
                .build()
        }
    }

    private var wakeLock: PowerManager.WakeLock? = null
    private val handler = Handler(Looper.getMainLooper())

    // กันระบบหน่วง/หยุดงานพื้นหลังตอนล็อกหน้าจอ คอยปลุกให้ worker ทำงานต่อเรื่อยๆ
    private val tick = object : Runnable {
        override fun run() {
            UploadManager.startWorker(this@KeepAliveService)
            handler.postDelayed(this, 15000)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        startForeground(NOTIF_ID, build(this, UploadManager.pendingCount(this)), ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        running = true
        UploadManager.startWorker(this)
        if (wakeLock == null) {
            val pm = getSystemService(PowerManager::class.java)
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "carreceivestep:keepalive").apply {
                setReferenceCounted(false)
                acquire()
            }
            handler.postDelayed(tick, 15000)
        }
        return START_STICKY
    }

    override fun onDestroy() {
        running = false
        handler.removeCallbacks(tick)
        wakeLock?.let { if (it.isHeld) it.release() }
        wakeLock = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
