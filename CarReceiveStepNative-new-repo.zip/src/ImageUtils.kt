package com.mycompany.carreceivestep2

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Typeface
import android.media.ExifInterface
import android.net.Uri
import java.io.ByteArrayOutputStream
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID
import kotlin.math.max
import kotlin.math.min

// รวมฟังก์ชันช่วยเรื่องรูปภาพ ใช้กับรูปที่ "เลือกจากเครื่อง" (กล้อง burst บีบอัดของตัวเองอยู่แล้วใน BurstCameraActivity)
object ImageUtils {

    private const val MAX_BYTES = 200 * 1024

    // คัดลอกรูปจาก uri ต้นทาง (เช่นจาก gallery picker) มาบีบอัดแล้วเก็บเป็นไฟล์ส่วนตัวของแอป
    // คืนค่า null ถ้าอ่าน/ประมวลผลรูปไม่สำเร็จ
    fun stageToLocalFile(context: Context, source: Uri, destDir: File): File? {
        return try {
            destDir.mkdirs()
            val outFile = File(destDir, "${UUID.randomUUID()}.jpg")

            val orientation = context.contentResolver.openInputStream(source)?.use {
                runCatching { ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL) }
                    .getOrDefault(ExifInterface.ORIENTATION_NORMAL)
            } ?: ExifInterface.ORIENTATION_NORMAL
            val degrees = when (orientation) {
                ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                else -> 0f
            }

            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            context.contentResolver.openInputStream(source)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null

            val longSide = max(bounds.outWidth, bounds.outHeight)
            var sample = 1
            while (longSide / sample > 2400) sample *= 2

            val opts = BitmapFactory.Options().apply { inSampleSize = sample }
            var bmp = context.contentResolver.openInputStream(source)?.use {
                BitmapFactory.decodeStream(it, null, opts)
            } ?: return null

            if (degrees != 0f) {
                val m = Matrix().apply { postRotate(degrees) }
                val rotated = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
                if (rotated !== bmp) bmp.recycle()
                bmp = rotated
            }

            val w = bmp.width
            val h = bmp.height
            var scale = min(1f, 1600f / max(w, h))
            var out: ByteArray? = null
            while (true) {
                val b = if (scale < 1f) {
                    Bitmap.createScaledBitmap(bmp, max(1, (w * scale).toInt()), max(1, (h * scale).toInt()), true)
                } else bmp
                var q = 85
                var data = encode(b, q)
                while (data.size > MAX_BYTES && q > 45) {
                    q -= 10
                    data = encode(b, q)
                }
                if (b !== bmp) b.recycle()
                if (data.size <= MAX_BYTES || scale < 0.2f) {
                    out = data
                    break
                }
                scale *= 0.85f
            }
            bmp.recycle()

            val bytes = out ?: return null
            outFile.writeBytes(bytes)
            outFile
        } catch (e: Exception) {
            null
        }
    }

    private fun encode(b: Bitmap, q: Int): ByteArray {
        val bos = ByteArrayOutputStream()
        b.compress(Bitmap.CompressFormat.JPEG, q, bos)
        return bos.toByteArray()
    }

    // สร้างรูปการ์ดสรุปข้อมูลใบงาน (ป้ายทะเบียน/ประกัน/พนักงาน/วันเวลา) เป็นรูปแรกก่อนส่งเข้าคิว
    fun createSummaryCard(
        destDir: File,
        plate: String,
        insurance: String,
        employee: String,
        timestamp: Date
    ): File? {
        return try {
            destDir.mkdirs()
            val width = 1080
            val height = 1350

            val bmp = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(bmp)
            canvas.drawColor(Color.parseColor("#1B1B1B"))

            val tagPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.parseColor("#FF7A3D")
                textSize = 40f
                typeface = Typeface.DEFAULT_BOLD
            }
            canvas.drawText("รับรถเข้าศูนย์ซ่อมสี", 60f, 130f, tagPaint)

            val titlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.WHITE
                textSize = 58f
                typeface = Typeface.DEFAULT_BOLD
            }
            canvas.drawText("ใบตรวจสภาพรถก่อนซ่อม", 60f, 210f, titlePaint)

            val linePaint = Paint().apply {
                color = Color.parseColor("#33FFFFFF")
                strokeWidth = 2f
            }
            canvas.drawLine(60f, 250f, width - 60f, 250f, linePaint)

            val labelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.parseColor("#BBBBBB")
                textSize = 32f
            }
            val valuePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.WHITE
                textSize = 48f
                typeface = Typeface.DEFAULT_BOLD
            }

            val timeFmt = SimpleDateFormat("dd/MM/yyyy HH:mm:ss", Locale.US)
            val rows = listOf(
                "ป้ายทะเบียน" to plate.ifBlank { "ไม่ระบุ" },
                "บริษัทประกัน" to insurance.ifBlank { "ไม่ระบุ" },
                "พนักงานที่รับรถ" to employee.ifBlank { "ไม่ระบุ" },
                "วันเวลาที่ถ่าย" to timeFmt.format(timestamp)
            )

            var y = 360f
            rows.forEach { (label, value) ->
                canvas.drawText(label, 60f, y, labelPaint)
                y += 56f
                canvas.drawText(value, 60f, y, valuePaint)
                y += 120f
            }

            val outFile = File(destDir, "${UUID.randomUUID()}.jpg")
            outFile.writeBytes(encode(bmp, 90))
            bmp.recycle()
            outFile
        } catch (e: Exception) {
            null
        }
    }

    // คัดลอกไฟล์จาก MediaStore uri (เช่นรูปจากกล้อง burst ซึ่งบีบอัดมาแล้ว) มาเก็บในพื้นที่ส่วนตัวของแอป โดยไม่ประมวลผลซ้ำ
    fun copyRawToLocalFile(context: Context, source: Uri, destDir: File): File? {
        return try {
            destDir.mkdirs()
            val outFile = File(destDir, "${UUID.randomUUID()}.jpg")
            context.contentResolver.openInputStream(source)?.use { input ->
                outFile.outputStream().use { output -> input.copyTo(output) }
            } ?: return null
            outFile
        } catch (e: Exception) {
            null
        }
    }
}
