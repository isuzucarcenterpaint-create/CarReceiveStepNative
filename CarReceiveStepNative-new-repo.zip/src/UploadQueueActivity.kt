package com.mycompany.carreceivestep2

import android.app.AlertDialog
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.activity.ComponentActivity
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// หน้าจอดูคิวการอัปโหลด: แสดงใบงานทั้งหมดที่ยังค้างอยู่ พร้อมสถานะและปุ่มจัดการ
class UploadQueueActivity : ComponentActivity() {

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private lateinit var listLayout: LinearLayout
    private val dateFmt = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.US)

    private val listener: (Int) -> Unit = { runOnUiThread { refreshList() } }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#EDEAE3"))
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(Color.parseColor("#1B1B1B"))
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(20), dp(20), dp(20), dp(20))
        }
        val title = TextView(this).apply {
            text = "คิวการอัปโหลด"
            setTextColor(Color.WHITE)
            textSize = 22f
            typeface = Typeface.DEFAULT_BOLD
        }
        header.addView(title)
        root.addView(header, LinearLayout.LayoutParams(-1, -2))

        val scroll = ScrollView(this)
        listLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(20), dp(20), dp(20))
        }
        scroll.addView(listLayout)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        UploadManager.addListener(listener)
        refreshList()
    }

    override fun onPause() {
        super.onPause()
        UploadManager.removeListener(listener)
    }

    private fun refreshList() {
        listLayout.removeAllViews()
        val tickets = UploadManager.snapshot(this)

        if (tickets.isEmpty()) {
            val empty = TextView(this).apply {
                text = "ไม่มีใบงานค้างอยู่ในคิว"
                setTextColor(Color.parseColor("#888888"))
                textSize = 15f
                gravity = Gravity.CENTER
                setPadding(0, dp(40), 0, 0)
            }
            listLayout.addView(empty)
            return
        }

        tickets.forEach { t -> listLayout.addView(ticketCard(t)) }
    }

    private fun ticketCard(t: TicketSnapshot): LinearLayout {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(16))
            background = GradientDrawable().apply {
                cornerRadius = dp(12).toFloat()
                setColor(Color.WHITE)
            }
        }

        val plateText = t.plate.ifBlank { "ไม่ระบุทะเบียน" }
        val title = TextView(this).apply {
            text = plateText
            setTextColor(Color.parseColor("#1B1B1B"))
            textSize = 17f
            typeface = Typeface.DEFAULT_BOLD
        }
        card.addView(title)

        val detail = TextView(this).apply {
            val emp = t.employee.ifBlank { "-" }
            val ins = t.insurance.ifBlank { "-" }
            text = "พนักงาน: $emp   ประกัน: $ins"
            setTextColor(Color.parseColor("#555555"))
            textSize = 13f
            setPadding(0, dp(4), 0, 0)
        }
        card.addView(detail)

        val progressText = TextView(this).apply {
            text = if (t.sentPhotos >= t.totalPhotos && !t.finishSent) {
                "ส่งรูปครบแล้ว (${t.sentPhotos}/${t.totalPhotos}) รอส่งข้อมูลสรุป"
            } else {
                "ส่งแล้ว ${t.sentPhotos}/${t.totalPhotos} รูป"
            }
            setTextColor(Color.parseColor("#333333"))
            textSize = 13f
            setPadding(0, dp(6), 0, 0)
        }
        card.addView(progressText)

        val timeText = TextView(this).apply {
            text = "เข้าคิวเมื่อ ${dateFmt.format(Date(t.createdAt))}"
            setTextColor(Color.parseColor("#999999"))
            textSize = 12f
            setPadding(0, dp(2), 0, 0)
        }
        card.addView(timeText)

        val statusText = TextView(this).apply {
            if (t.notifiedFailure) {
                text = "⚠ ค้างมีปัญหา ยังส่งไม่สำเร็จ กำลังลองใหม่เรื่อยๆ"
                setTextColor(Color.parseColor("#C62828"))
            } else {
                text = "กำลังส่ง…"
                setTextColor(Color.parseColor("#2E7D32"))
            }
            textSize = 13f
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, dp(8), 0, 0)
        }
        card.addView(statusText)

        val btnRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, dp(12), 0, 0)
        }

        val retryBtn = Button(this).apply {
            text = "ลองส่งใหม่ตอนนี้"
            setOnClickListener { UploadManager.retryNow(this@UploadQueueActivity) }
        }
        btnRow.addView(retryBtn, LinearLayout.LayoutParams(0, -2, 1f).apply { marginEnd = dp(8) })

        val cancelBtn = Button(this).apply {
            text = "ยกเลิกใบงาน"
            setOnClickListener { confirmCancel(t) }
        }
        btnRow.addView(cancelBtn, LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(8) })

        card.addView(btnRow)

        return card
    }

    private fun confirmCancel(t: TicketSnapshot) {
        val plateText = t.plate.ifBlank { "ไม่ระบุทะเบียน" }
        AlertDialog.Builder(this)
            .setTitle("ยกเลิกใบงานนี้?")
            .setMessage("ใบงาน $plateText จะถูกลบออกจากคิวและลบรูปที่ยังไม่ได้ส่งทั้งหมดในเครื่อง การกระทำนี้ย้อนกลับไม่ได้")
            .setPositiveButton("ยกเลิกใบงาน") { _, _ ->
                UploadManager.cancelTicket(this, t.folderName)
            }
            .setNegativeButton("ปิด", null)
            .show()
    }
}
