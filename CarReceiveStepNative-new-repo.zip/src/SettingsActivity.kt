package com.mycompany.carreceivestep2

import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity

class SettingsActivity : ComponentActivity() {

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private lateinit var urlInput: EditText
    private lateinit var testButton: Button
    private lateinit var statusText: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#EDEAE3"))
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(Color.parseColor("#1B1B1B"))
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(20), dp(20), dp(20), dp(20))
        }
        val title = TextView(this).apply {
            text = "ตั้งค่า"
            setTextColor(Color.WHITE)
            textSize = 22f
            typeface = Typeface.DEFAULT_BOLD
        }
        header.addView(title)
        root.addView(header, LinearLayout.LayoutParams(-1, -2))

        val scroll = ScrollView(this)
        val body = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(24), dp(20), dp(24))
        }

        val label = TextView(this).apply {
            text = "ลิงก์ Google Apps Script"
            textSize = 15f
            setTextColor(Color.parseColor("#333333"))
            setPadding(0, 0, 0, dp(8))
        }
        body.addView(label)

        urlInput = EditText(this).apply {
            hint = "https://script.google.com/macros/s/xxxx/exec"
            inputType = InputType.TYPE_TEXT_VARIATION_URI
            setText(UploadManager.getScriptUrl(this@SettingsActivity))
            setPadding(dp(16), dp(14), dp(16), dp(14))
            setBackgroundColor(Color.WHITE)
        }
        body.addView(urlInput, LinearLayout.LayoutParams(-1, -2))

        val hint = TextView(this).apply {
            text = "ระบบจะจดจำลิงก์นี้ไว้จนกว่าจะมาเปลี่ยนใหม่ที่หน้านี้อีกครั้ง"
            textSize = 12f
            setTextColor(Color.parseColor("#888888"))
            setPadding(0, dp(8), 0, dp(20))
        }
        body.addView(hint)

        val btnRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }

        testButton = Button(this).apply {
            text = "ทดสอบสคริป"
            setOnClickListener { onTestClicked() }
        }
        btnRow.addView(testButton, LinearLayout.LayoutParams(0, -2, 1f).apply { marginEnd = dp(8) })

        val saveButton = Button(this).apply {
            text = "บันทึก"
            setOnClickListener { onSaveClicked() }
        }
        btnRow.addView(saveButton, LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(8) })

        body.addView(btnRow, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(4) })

        statusText = TextView(this).apply {
            textSize = 14f
            setPadding(0, dp(16), 0, 0)
            visibility = View.GONE
        }
        body.addView(statusText)

        scroll.addView(body)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        setContentView(root)
    }

    private fun onTestClicked() {
        val url = urlInput.text.toString().trim()
        if (url.isBlank()) {
            Toast.makeText(this, "กรุณาใส่ลิงก์ก่อน", Toast.LENGTH_SHORT).show()
            return
        }
        testButton.isEnabled = false
        statusText.visibility = View.VISIBLE
        statusText.setTextColor(Color.parseColor("#666666"))
        statusText.text = "กำลังทดสอบ…"
        UploadManager.testScript(url) { success, message ->
            testButton.isEnabled = true
            statusText.setTextColor(if (success) Color.parseColor("#2E7D32") else Color.parseColor("#C62828"))
            statusText.text = message
        }
    }

    private fun onSaveClicked() {
        val url = urlInput.text.toString().trim()
        UploadManager.saveScriptUrl(this, url)
        Toast.makeText(this, "บันทึกแล้ว", Toast.LENGTH_SHORT).show()
        finish()
    }
}
