package com.mycompany.carreceivestep2

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.Looper
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors
import android.util.Base64

// ข้อมูลรูป 1 ใบที่รอส่ง (ไฟล์เก็บไว้ในพื้นที่ส่วนตัวของแอปแล้ว ไม่พึ่ง content uri ภายนอกอีกต่อไป)
data class PendingPhoto(
    val fileId: String,
    val filePath: String,
    var sent: Boolean = false
)

// ใบงานรับรถ 1 คัน = 1 ชุดที่ต้องส่ง (รูปทุกใบ + finish)
data class Ticket(
    val folderName: String,
    val plate: String,
    val employee: String,
    val insurance: String,
    val photos: MutableList<PendingPhoto>,
    var finishSent: Boolean = false,
    val createdAt: Long = System.currentTimeMillis(),
    var notifiedFailure: Boolean = false
) {
    fun isDone(): Boolean = finishSent
    fun pendingItemCount(): Int {
        val unsentPhotos = photos.count { !it.sent }
        val finishPending = if (photos.all { it.sent } && !finishSent) 1 else 0
        return unsentPhotos + finishPending
    }
}

// สแนปช็อตแบบอ่านอย่างเดียวของใบงาน 1 ใบ ให้หน้าจอดูคิวใช้แสดงผล
// (ไม่ให้ UI ถือ reference ของ Ticket จริงโดยตรง กันแก้ไข/อ่านชนกับ worker thread)
data class TicketSnapshot(
    val folderName: String,
    val plate: String,
    val employee: String,
    val insurance: String,
    val totalPhotos: Int,
    val sentPhotos: Int,
    val finishSent: Boolean,
    val createdAt: Long,
    val notifiedFailure: Boolean
)

// จัดการคิวส่งข้อมูลไป Google Apps Script: เก็บคิวลงดิสก์กันแอปโดนปิดแล้วข้อมูลหาย,
// รันเธรดพื้นหลังพยายามส่งซ้ำเรื่อยๆ จนสำเร็จ, แจ้งเตือนถ้าใบไหนค้างนานเกิน 5 นาที
object UploadManager {

    private const val PREFS = "car_receive_prefs"
    private const val KEY_SCRIPT_URL = "script_url"
    private const val QUEUE_FILE = "upload_queue.json"
    private const val STAGING_DIR = "pending_photos"
    private const val FAILURE_NOTIFY_AFTER_MS = 5 * 60 * 1000L
    private const val CHANNEL_ALERT = "upload_alert"
    private const val BATCH_SIZE = 4 // ลดเหลือ 4 รูปต่อ request เพราะสคริป Apps Script ใช้เวลาบันทึกลง Drive นาน

    private val tickets = mutableListOf<Ticket>()
    private var loaded = false
    private val worker = Executors.newSingleThreadExecutor() // เธรดเดียว ใช้เฉพาะ retry loop ระยะยาว
    private val quickExecutor = Executors.newCachedThreadPool() // งานสั้นๆ เช่นทดสอบสคริป ไม่ต้องรอคิว retry
    @Volatile private var workerRunning = false
    @Volatile private var workerThread: Thread? = null
    private val mainHandler = Handler(Looper.getMainLooper())

    val listeners = mutableListOf<(Int) -> Unit>()

    fun stagingDir(context: Context): File = File(context.filesDir, STAGING_DIR)

    fun getScriptUrl(context: Context): String {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_SCRIPT_URL, "") ?: ""
    }

    fun saveScriptUrl(context: Context, url: String) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString(KEY_SCRIPT_URL, url.trim())
            .apply()
    }

    @Synchronized
    fun pendingCount(context: Context): Int {
        ensureLoaded(context)
        return tickets.sumOf { it.pendingItemCount() }
    }

    // ให้หน้าจอดูคิวเรียกดูสถานะใบงานทั้งหมดที่ยังค้างอยู่ เรียงจากเก่าไปใหม่
    @Synchronized
    fun snapshot(context: Context): List<TicketSnapshot> {
        ensureLoaded(context)
        return tickets.map {
            TicketSnapshot(
                folderName = it.folderName,
                plate = it.plate,
                employee = it.employee,
                insurance = it.insurance,
                totalPhotos = it.photos.size,
                sentPhotos = it.photos.count { p -> p.sent },
                finishSent = it.finishSent,
                createdAt = it.createdAt,
                notifiedFailure = it.notifiedFailure
            )
        }.sortedBy { it.createdAt }
    }

    // ยกเลิกใบงาน: ลบออกจากคิว + ลบไฟล์รูปที่ยังค้างอยู่ในเครื่องทั้งหมดของใบงานนั้น
    // (ถ้า worker กำลังส่งรูปใบงานนี้อยู่พอดี อาจส่งไม่สำเร็จแล้วถูกข้ามไปเอง ไม่ทำให้แอปพัง)
    @Synchronized
    fun cancelTicket(context: Context, folderName: String) {
        ensureLoaded(context)
        val ticket = tickets.find { it.folderName == folderName } ?: return
        tickets.remove(ticket)
        ticket.photos.forEach { runCatching { File(it.filePath).delete() } }
        persist(context)
        notifyListeners(context)
    }

    // สั่งให้ worker ลองส่งใหม่ทันที ไม่ต้องรอ backoff เดิม
    fun retryNow(context: Context) {
        val appContext = context.applicationContext
        if (workerRunning) {
            workerThread?.interrupt() // ปลุกจาก Thread.sleep ให้วนกลับไปลองส่งรอบใหม่ทันที
        } else {
            startWorker(appContext)
        }
    }

    fun addListener(l: (Int) -> Unit) { listeners.add(l) }
    fun removeListener(l: (Int) -> Unit) { listeners.remove(l) }

    private fun notifyListeners(context: Context) {
        val n = pendingCount(context)
        mainHandler.post { listeners.forEach { it(n) } }
        KeepAliveService.onPendingChanged(context, n)
    }

    @Synchronized
    private fun ensureLoaded(context: Context) {
        if (loaded) return
        loaded = true
        try {
            val f = File(context.filesDir, QUEUE_FILE)
            if (f.exists()) {
                val arr = JSONArray(f.readText())
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    val photosArr = o.getJSONArray("photos")
                    val photos = mutableListOf<PendingPhoto>()
                    for (j in 0 until photosArr.length()) {
                        val p = photosArr.getJSONObject(j)
                        photos.add(PendingPhoto(p.getString("fileId"), p.getString("filePath"), p.getBoolean("sent")))
                    }
                    tickets.add(
                        Ticket(
                            folderName = o.getString("folderName"),
                            plate = o.getString("plate"),
                            employee = o.getString("employee"),
                            insurance = o.getString("insurance"),
                            photos = photos,
                            finishSent = o.getBoolean("finishSent"),
                            createdAt = o.optLong("createdAt", System.currentTimeMillis()),
                            notifiedFailure = o.optBoolean("notifiedFailure", false)
                        )
                    )
                }
            }
        } catch (e: Exception) {
            // ไฟล์คิวเสีย ปล่อยว่างไว้ ดีกว่าแอปพัง
        }
    }

    @Synchronized
    private fun persist(context: Context) {
        try {
            val arr = JSONArray()
            for (t in tickets) {
                val photosArr = JSONArray()
                for (p in t.photos) {
                    photosArr.put(JSONObject().apply {
                        put("fileId", p.fileId)
                        put("filePath", p.filePath)
                        put("sent", p.sent)
                    })
                }
                arr.put(JSONObject().apply {
                    put("folderName", t.folderName)
                    put("plate", t.plate)
                    put("employee", t.employee)
                    put("insurance", t.insurance)
                    put("photos", photosArr)
                    put("finishSent", t.finishSent)
                    put("createdAt", t.createdAt)
                    put("notifiedFailure", t.notifiedFailure)
                })
            }
            File(context.filesDir, QUEUE_FILE).writeText(arr.toString())
        } catch (e: Exception) {
        }
    }

    // เรียกตอนกด "ยืนยันเสร็จสิ้น" ในหน้าหลัก ไฟล์รูปต้องถูกย้ายมาไว้ใน stagingDir(context) แล้วก่อนเรียกฟังก์ชันนี้
    @Synchronized
    fun enqueue(context: Context, folderName: String, plate: String, employee: String, insurance: String, photoFiles: List<File>) {
        ensureLoaded(context)
        val photos = photoFiles.mapIndexed { idx, f -> PendingPhoto(fileId = (idx + 1).toString(), filePath = f.absolutePath) }.toMutableList()
        tickets.add(Ticket(folderName = folderName, plate = plate, employee = employee, insurance = insurance, photos = photos))
        persist(context)
        notifyListeners(context)
        KeepAliveService.start(context)
        startWorker(context)
    }

    fun startWorker(context: Context) {
        if (workerRunning) return
        workerRunning = true
        val appContext = context.applicationContext
        worker.execute { runLoop(appContext) }
    }

    private fun runLoop(context: Context) {
        workerThread = Thread.currentThread()
        var backoffMs = 3000L
        val maxBackoff = 30000L
        try {
            while (true) {
                ensureLoaded(context)
                val scriptUrl = getScriptUrl(context)
                if (scriptUrl.isBlank()) {
                    // ไม่มีลิงก์สคริปตั้งไว้ รอเฉยๆ ไม่ต้องยิง request เปล่าๆ
                    try { Thread.sleep(5000) } catch (ie: InterruptedException) { /* ปลุกโดย retryNow ไม่มีผลตรงนี้ */ }
                    if (pendingCount(context) == 0) break
                    continue
                }

                var madeProgress = false
                val snapshot: List<Ticket> = synchronized(this) { tickets.toList() }

                for (ticket in snapshot) {
                    if (ticket.isDone()) continue
                    var ticketFailed = false

                    val unsentPhotos = ticket.photos.filter { !it.sent }
                    if (unsentPhotos.isNotEmpty()) {
                        for (batch in unsentPhotos.chunked(BATCH_SIZE)) {
                            val ok = trySendBatch(scriptUrl, ticket.folderName, batch)
                            if (ok) {
                                synchronized(this) { batch.forEach { it.sent = true } }
                                persist(context)
                                notifyListeners(context)
                                madeProgress = true
                            } else {
                                ticketFailed = true
                                break // ไปลองใบงานอื่นก่อน ไม่ตันอยู่ที่ชุดเดิม
                            }
                        }
                    }

                    if (!ticketFailed && ticket.photos.all { it.sent } && !ticket.finishSent) {
                        val ok = trySendFinish(scriptUrl, ticket)
                        if (ok) {
                            synchronized(this) {
                                ticket.finishSent = true
                                tickets.remove(ticket)
                                // ลบไฟล์รูปที่ส่งสำเร็จแล้วทั้งหมดของใบนี้
                                ticket.photos.forEach { runCatching { File(it.filePath).delete() } }
                            }
                            persist(context)
                            notifyListeners(context)
                            madeProgress = true
                        } else {
                            ticketFailed = true
                        }
                    }

                    if (ticketFailed) {
                        val elapsed = System.currentTimeMillis() - ticket.createdAt
                        if (elapsed >= FAILURE_NOTIFY_AFTER_MS && !ticket.notifiedFailure) {
                            synchronized(this) { ticket.notifiedFailure = true }
                            persist(context)
                            notifyFailure(context, ticket)
                        }
                    }
                }

                if (pendingCount(context) == 0) break

                backoffMs = if (madeProgress) 3000L else min(backoffMs * 2, maxBackoff)
                try {
                    Thread.sleep(backoffMs)
                } catch (ie: InterruptedException) {
                    // ถูกปลุกโดย retryNow() ให้วนกลับไปลองส่งใหม่ทันที ไม่ต้องรอ backoff ที่เหลือ
                }
            }
        } finally {
            workerRunning = false
            workerThread = null
            if (pendingCount(context) == 0) {
                KeepAliveService.stop(context)
            }
        }
    }

    private fun min(a: Long, b: Long) = if (a < b) a else b

    private fun trySendBatch(scriptUrl: String, folderName: String, batch: List<PendingPhoto>): Boolean {
        return try {
            val photosArr = JSONArray()
            for (photo in batch) {
                val file = File(photo.filePath)
                if (!file.exists()) continue // ไฟล์หายไปแล้ว (เช่นเคยส่งสำเร็จแต่ persist ไม่ทัน) ข้ามไปเลยกันค้างตลอดกาล
                val bytes = file.readBytes()
                val b64 = Base64.encodeToString(bytes, Base64.NO_WRAP)
                photosArr.put(JSONObject().apply {
                    put("fileId", photo.fileId)
                    put("photo", "data:image/jpeg;base64,$b64")
                })
            }
            val body = JSONObject().apply {
                put("action", "batch")
                put("folderName", folderName)
                put("photos", photosArr)
            }
            val resp = Http.postJson(scriptUrl, body.toString(), 150000)
            JSONObject(resp).optString("status") == "ok"
        } catch (e: Exception) {
            false
        }
    }

    private fun trySendFinish(scriptUrl: String, ticket: Ticket): Boolean {
        return try {
            val body = JSONObject().apply {
                put("action", "finish")
                put("folderName", ticket.folderName)
                put("plate", ticket.plate)
                put("employee", ticket.employee)
                put("insurance", ticket.insurance)
                put("count", ticket.photos.size)
            }
            val resp = Http.postJson(scriptUrl, body.toString(), 20000)
            JSONObject(resp).optString("status") == "ok"
        } catch (e: Exception) {
            false
        }
    }

    private fun notifyFailure(context: Context, ticket: Ticket) {
        val nm = context.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_ALERT, "แจ้งเตือนการส่งข้อมูล", NotificationManager.IMPORTANCE_DEFAULT)
        )
        val open = PendingIntent.getActivity(
            context, ticket.folderName.hashCode(),
            Intent(context, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val notif = Notification.Builder(context, CHANNEL_ALERT)
            .setSmallIcon(android.R.drawable.stat_notify_error)
            .setContentTitle("ส่งข้อมูลไม่สำเร็จ")
            .setContentText("ใบงาน ${ticket.folderName} ยังส่งไม่สำเร็จ กำลังลองใหม่เรื่อยๆ")
            .setContentIntent(open)
            .setAutoCancel(true)
            .build()
        nm.notify(ticket.folderName.hashCode(), notif)
    }

    // ---- ใช้จากหน้าตั้งค่า: ทดสอบว่าลิงก์สคริปใช้งานได้ไหม ----
    fun testScript(scriptUrl: String, callback: (success: Boolean, message: String) -> Unit) {
        quickExecutor.execute {
            val result = try {
                val resp = Http.getJson(scriptUrl, 15000)
                val ok = JSONObject(resp).optString("status") == "ok"
                ok to if (ok) "เชื่อมต่อสำเร็จ" else "เชื่อมต่อได้ แต่รูปแบบคำตอบไม่ถูกต้อง"
            } catch (e: Exception) {
                false to "เชื่อมต่อไม่สำเร็จ: ${e.message}"
            }
            mainHandler.post { callback(result.first, result.second) }
        }
    }
}

// ตัวช่วยยิง HTTP ง่ายๆ ไม่พึ่ง library ภายนอก
object Http {
    fun postJson(urlStr: String, body: String, timeoutMs: Int): String {
        val conn = URL(urlStr).openConnection() as HttpURLConnection
        try {
            conn.requestMethod = "POST"
            conn.doOutput = true
            conn.connectTimeout = timeoutMs
            conn.readTimeout = timeoutMs
            conn.setRequestProperty("Content-Type", "application/json; charset=utf-8")
            conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val text = stream?.bufferedReader()?.use { it.readText() } ?: ""
            if (code !in 200..299) throw RuntimeException("HTTP $code: $text")
            return text
        } finally {
            conn.disconnect()
        }
    }

    fun getJson(urlStr: String, timeoutMs: Int): String {
        val conn = URL(urlStr).openConnection() as HttpURLConnection
        try {
            conn.requestMethod = "GET"
            conn.connectTimeout = timeoutMs
            conn.readTimeout = timeoutMs
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val text = stream?.bufferedReader()?.use { it.readText() } ?: ""
            if (code !in 200..299) throw RuntimeException("HTTP $code: $text")
            return text
        } finally {
            conn.disconnect()
        }
    }
}
