package com.mycompany.carreceivestep2

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.GridLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors

class MainActivity : ComponentActivity() {

    companion object {
        private const val REQ_STARTUP = 100
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private val ioExecutor = Executors.newSingleThreadExecutor()
    private val mainHandler = Handler(Looper.getMainLooper())

    // --- state ---
    private var stagedPhotos = mutableListOf<File>()
    private var ticketId = ""
    private var isDarkMode = false

    // --- views that need re-theming ---
    private lateinit var rootScroll: ScrollView
    private lateinit var bodyLayout: LinearLayout
    private lateinit var headerLayout: LinearLayout
    private lateinit var titleText: TextView
    private lateinit var ticketText: TextView
    private lateinit var card1: LinearLayout
    private lateinit var card2: LinearLayout
    private lateinit var plateInput: EditText
    private lateinit var employeeInput: EditText
    private lateinit var insuranceInput: EditText
    private lateinit var thumbGrid: GridLayout
    private lateinit var emptyPhotosText: TextView
    private lateinit var confirmButton: Button
    private lateinit var queueBtn: TextView

    private val pendingListener: (Int) -> Unit = { n -> mainHandler.post { updateQueueBadge(n) } }

    private val cardTextViews = mutableListOf<TextView>()
    private val labelTextViews = mutableListOf<TextView>()

    private val cameraLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == RESULT_OK) {
            val uris = extractUris(result.data)
            if (uris.isNotEmpty()) handleNewPhotos(uris, raw = true)
        }
    }

    private val galleryLauncher = registerForActivityResult(ActivityResultContracts.GetMultipleContents()) { uris ->
        if (uris.isNotEmpty()) handleNewPhotos(uris, raw = false)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ticketId = newTicketId()
        buildUi()
        applyTheme()
        requestStartupPermissions()
        updateQueueBadge(UploadManager.pendingCount(this)) // triggers load of queue from disk
        UploadManager.addListener(pendingListener)
    }

    override fun onResume() {
        super.onResume()
        refreshThumbnails()
        updateQueueBadge(UploadManager.pendingCount(this))
    }

    override fun onDestroy() {
        super.onDestroy()
        UploadManager.removeListener(pendingListener)
    }

    private fun updateQueueBadge(n: Int) {
        queueBtn.text = if (n > 0) "คิว ($n)" else "คิว"
    }

    // ---------------- permissions ----------------

    private fun requestStartupPermissions() {
        val needed = mutableListOf<String>()
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            needed.add(Manifest.permission.CAMERA)
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            needed.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        if (needed.isNotEmpty()) {
            requestPermissions(needed.toTypedArray(), REQ_STARTUP)
        } else {
            askBatteryOptimization()
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQ_STARTUP) askBatteryOptimization()
    }

    private fun askBatteryOptimization() {
        val pm = getSystemService(PowerManager::class.java)
        if (!pm.isIgnoringBatteryOptimizations(packageName)) {
            try {
                startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
            } catch (e: Exception) {
            }
        }
    }

    // ---------------- photo capture / pick ----------------

    private fun extractUris(data: Intent?): List<Uri> {
        val list = mutableListOf<Uri>()
        val clip = data?.clipData
        if (clip != null) {
            for (i in 0 until clip.itemCount) list.add(clip.getItemAt(i).uri)
        } else {
            data?.data?.let { list.add(it) }
        }
        return list
    }

    private fun handleNewPhotos(uris: List<Uri>, raw: Boolean) {
        Toast.makeText(this, "กำลังประมวลผลรูป…", Toast.LENGTH_SHORT).show()
        ioExecutor.execute {
            val dir = UploadManager.stagingDir(this)
            val results = uris.mapNotNull { u ->
                if (raw) ImageUtils.copyRawToLocalFile(this, u, dir) else ImageUtils.stageToLocalFile(this, u, dir)
            }
            mainHandler.post {
                stagedPhotos.addAll(results)
                refreshThumbnails()
                if (results.size < uris.size) {
                    Toast.makeText(this, "บางรูปประมวลผลไม่สำเร็จ", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    private fun removeStagedPhoto(file: File) {
        stagedPhotos.remove(file)
        runCatching { file.delete() }
        refreshThumbnails()
    }

    // ---------------- ticket / submit ----------------

    private fun newTicketId(): String = SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US).format(Date())

    private fun buildFolderName(plate: String, insurance: String): String {
        val now = Date()
        val datePart = SimpleDateFormat("dd-MM-yyyy", Locale.US).format(now)
        val timePart = SimpleDateFormat("HH-mm-ss", Locale.US).format(now)
        val plateSafe = plate.ifBlank { "ไม่ระบุทะเบียน" }
        val insuranceSafe = insurance.ifBlank { "ไม่ระบุประกัน" }
        return "${plateSafe}_${insuranceSafe}_${datePart}_$timePart"
    }

    private fun onConfirmClicked() {
        if (stagedPhotos.isEmpty()) {
            Toast.makeText(this, "กรุณาถ่ายรูปอย่างน้อย 1 รูปก่อนยืนยัน", Toast.LENGTH_SHORT).show()
            return
        }
        val scriptUrl = UploadManager.getScriptUrl(this)
        if (scriptUrl.isBlank()) {
            Toast.makeText(this, "กรุณาตั้งค่าลิงก์ Google Apps Script ก่อน", Toast.LENGTH_LONG).show()
            startActivity(Intent(this, SettingsActivity::class.java))
            return
        }

        val plate = plateInput.text.toString().trim()
        val employee = employeeInput.text.toString().trim()
        val insurance = insuranceInput.text.toString().trim()
        val folderName = buildFolderName(plate, insurance)

        val summaryCard = ImageUtils.createSummaryCard(
            destDir = UploadManager.stagingDir(this),
            plate = plate,
            insurance = insurance,
            employee = employee,
            timestamp = Date()
        )
        val photos = if (summaryCard != null) listOf(summaryCard) + stagedPhotos.toList() else stagedPhotos.toList()

        UploadManager.enqueue(this, folderName, plate, employee, insurance, photos)

        // เริ่มรถคันใหม่: ล้างฟอร์มและออกใบงานใหม่ (รูปที่เพิ่งส่งเข้าคิวเป็นของใบงานนี้แล้ว ไม่ลบไฟล์)
        stagedPhotos = mutableListOf()
        plateInput.setText("")
        employeeInput.setText("")
        insuranceInput.setText("")
        ticketId = newTicketId()
        ticketText.text = "เลขที่ใบงาน $ticketId"
        refreshThumbnails()

        Toast.makeText(this, "ส่งเข้าคิวแล้ว กำลังอัปโหลดเบื้องหลัง", Toast.LENGTH_LONG).show()
    }

    private fun onClearClicked() {
        plateInput.setText("")
        employeeInput.setText("")
        insuranceInput.setText("")
        stagedPhotos.forEach { runCatching { it.delete() } }
        stagedPhotos = mutableListOf()
        refreshThumbnails()
        Toast.makeText(this, "ล้างข้อมูลฟอร์มแล้ว", Toast.LENGTH_SHORT).show()
    }

    // ---------------- UI building ----------------

    private fun buildUi() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        headerLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(24), dp(20), dp(24))
        }

        val topRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val tag = TextView(this).apply {
            text = "รับรถเข้าศูนย์ซ่อมสี"
            setTextColor(Color.parseColor("#FF7A3D"))
            typeface = Typeface.DEFAULT_BOLD
            textSize = 14f
        }
        topRow.addView(tag, LinearLayout.LayoutParams(0, -2, 1f))

        val darkBtn = pillButton("โหมดมืด") { toggleDarkMode() }
        queueBtn = pillButton("คิว") { startActivity(Intent(this, UploadQueueActivity::class.java)) }
        val settingsBtn = pillButton("ตั้งค่า") { startActivity(Intent(this, SettingsActivity::class.java)) }
        topRow.addView(darkBtn, LinearLayout.LayoutParams(-2, -2).apply { marginEnd = dp(8) })
        topRow.addView(queueBtn, LinearLayout.LayoutParams(-2, -2).apply { marginEnd = dp(8) })
        topRow.addView(settingsBtn)
        headerLayout.addView(topRow, LinearLayout.LayoutParams(-1, -2))

        titleText = TextView(this).apply {
            text = "ใบตรวจสภาพรถก่อนซ่อม"
            setTextColor(Color.WHITE)
            textSize = 24f
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, dp(12), 0, dp(4))
        }
        headerLayout.addView(titleText, LinearLayout.LayoutParams(-1, -2))

        ticketText = TextView(this).apply {
            text = "เลขที่ใบงาน $ticketId"
            setTextColor(Color.parseColor("#BBBBBB"))
            textSize = 14f
        }
        headerLayout.addView(ticketText, LinearLayout.LayoutParams(-1, -2))

        root.addView(headerLayout, LinearLayout.LayoutParams(-1, -2))

        rootScroll = ScrollView(this)
        bodyLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(20), dp(20), dp(20))
        }

        bodyLayout.addView(sectionHeader("1", "ข้อมูลรถและลูกค้า"))

        card1 = cardContainer()
        val row1 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val plateBlock = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        plateBlock.addView(fieldLabel("ทะเบียนรถ"))
        plateInput = plainEditText("เช่น กข 1234")
        plateBlock.addView(plateInput, LinearLayout.LayoutParams(-1, -2))
        row1.addView(plateBlock, LinearLayout.LayoutParams(0, -2, 1f).apply { marginEnd = dp(10) })

        val empBlock = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        empBlock.addView(fieldLabel("พนักงานที่รับรถ"))
        employeeInput = plainEditText("ชื่อพนักงาน")
        empBlock.addView(employeeInput, LinearLayout.LayoutParams(-1, -2))
        row1.addView(empBlock, LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(10) })

        card1.addView(row1, LinearLayout.LayoutParams(-1, -2))

        val insBlock = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(16), 0, 0)
        }
        insBlock.addView(fieldLabel("บริษัทประกัน (ถ้ามี)"))
        insuranceInput = plainEditText("เช่น วิริยะประกันภัย")
        insBlock.addView(insuranceInput, LinearLayout.LayoutParams(-1, -2))
        card1.addView(insBlock, LinearLayout.LayoutParams(-1, -2))

        bodyLayout.addView(card1, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(24) })

        bodyLayout.addView(sectionHeader("2", "ถ่ายภาพสภาพรถ"))
        val desc = TextView(this).apply {
            text = "ถ่ายต่อเนื่องในหน้าเดียวได้เลย หรือเลือกรูปที่มีอยู่แล้วในเครื่องได้ทีละหลายรูป"
            textSize = 13f
            setPadding(0, 0, 0, dp(14))
        }
        cardTextViews.add(desc)
        bodyLayout.addView(desc)

        card2 = cardContainer()
        val actionRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        actionRow.addView(
            actionTile("📷", "ถ่ายรูปต่อเนื่อง", "เปิดกล้อง ถ่ายรัวๆ ในหน้าเดียว") {
                cameraLauncher.launch(Intent(this, BurstCameraActivity::class.java))
            },
            LinearLayout.LayoutParams(0, -2, 1f).apply { marginEnd = dp(8) }
        )
        actionRow.addView(
            actionTile("🖼️", "เลือกรูปจากเครื่อง", "เลือกได้หลายรูปพร้อมกัน") {
                galleryLauncher.launch("image/*")
            },
            LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(8) }
        )
        card2.addView(actionRow, LinearLayout.LayoutParams(-1, -2))

        emptyPhotosText = TextView(this).apply {
            text = "ยังไม่มีรูป"
            textSize = 13f
            setPadding(0, dp(16), 0, 0)
            gravity = Gravity.CENTER
        }
        card2.addView(emptyPhotosText, LinearLayout.LayoutParams(-1, -2))

        thumbGrid = GridLayout(this).apply {
            columnCount = 3
            setPadding(0, dp(12), 0, 0)
        }
        card2.addView(thumbGrid, LinearLayout.LayoutParams(-1, -2))

        bodyLayout.addView(card2, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(28) })

        confirmButton = Button(this).apply {
            text = "ยืนยันเสร็จสิ้น / เริ่มรถคันใหม่"
            setTextColor(Color.WHITE)
            setPadding(0, dp(18), 0, dp(18))
            setOnClickListener { onConfirmClicked() }
        }
        bodyLayout.addView(confirmButton, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) })

        val clearButton = Button(this).apply {
            text = "ล้างค่า"
            setOnClickListener { onClearClicked() }
        }
        bodyLayout.addView(clearButton, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(20) })

        rootScroll.addView(bodyLayout, ViewGroup.LayoutParams(-1, -2))
        root.addView(rootScroll, LinearLayout.LayoutParams(-1, 0, 1f))

        setContentView(root)
        refreshThumbnails()
    }

    private fun sectionHeader(num: String, text: String): LinearLayout {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, 0, 0, dp(12))
        }
        val badge = TextView(this).apply {
            this.text = num
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.parseColor("#FF7A3D"))
            }
        }
        row.addView(badge, LinearLayout.LayoutParams(dp(28), dp(28)).apply { marginEnd = dp(10) })
        val label = TextView(this).apply {
            this.text = text
            textSize = 19f
            typeface = Typeface.DEFAULT_BOLD
        }
        labelTextViews.add(label)
        row.addView(label)
        return row
    }

    private fun cardContainer(): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(18))
            background = GradientDrawable().apply {
                cornerRadius = dp(14).toFloat()
                setColor(Color.WHITE)
            }
        }
    }

    private fun fieldLabel(text: String): TextView {
        return TextView(this).apply {
            this.text = text
            textSize = 13f
            setPadding(0, 0, 0, dp(6))
        }.also { labelTextViews.add(it) }
    }

    private fun plainEditText(hintText: String): EditText {
        return EditText(this).apply {
            hint = hintText
            inputType = InputType.TYPE_CLASS_TEXT
            setPadding(dp(14), dp(14), dp(14), dp(14))
            background = GradientDrawable().apply {
                cornerRadius = dp(8).toFloat()
                setColor(Color.parseColor("#F2F0EA"))
            }
        }
    }

    private fun pillButton(text: String, onClick: () -> Unit): TextView {
        return TextView(this).apply {
            this.text = text
            setTextColor(Color.WHITE)
            textSize = 13f
            setPadding(dp(14), dp(10), dp(14), dp(10))
            background = GradientDrawable().apply {
                cornerRadius = dp(20).toFloat()
                setColor(Color.parseColor("#33FFFFFF"))
            }
            setOnClickListener { onClick() }
        }
    }

    private fun actionTile(emoji: String, title: String, subtitle: String, onClick: () -> Unit): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(14), dp(20), dp(14), dp(20))
            background = GradientDrawable().apply {
                cornerRadius = dp(12).toFloat()
                setStroke(dp(1), Color.parseColor("#CCCCCC"))
                setColor(Color.parseColor("#FAF9F6"))
            }
            addView(TextView(this@MainActivity).apply { text = emoji; textSize = 30f; gravity = Gravity.CENTER })
            addView(TextView(this@MainActivity).apply {
                text = title
                textSize = 15f
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.CENTER
                setPadding(0, dp(8), 0, dp(4))
            }.also { labelTextViews.add(it) })
            addView(TextView(this@MainActivity).apply {
                text = subtitle
                textSize = 11f
                gravity = Gravity.CENTER
            }.also { cardTextViews.add(it) })
            setOnClickListener { onClick() }
        }
    }

    // ---------------- thumbnails ----------------

    private fun refreshThumbnails() {
        thumbGrid.removeAllViews()
        emptyPhotosText.visibility = if (stagedPhotos.isEmpty()) View.VISIBLE else View.GONE
        thumbGrid.visibility = if (stagedPhotos.isEmpty()) View.GONE else View.VISIBLE

        val cellSize = dp(96)
        for (file in stagedPhotos) {
            val cell = FrameLayout(this).apply {
                layoutParams = GridLayout.LayoutParams().apply {
                    width = cellSize; height = cellSize
                    setMargins(dp(4), dp(4), dp(4), dp(4))
                }
            }
            val iv = ImageView(this).apply {
                layoutParams = FrameLayout.LayoutParams(-1, -1)
                scaleType = ImageView.ScaleType.CENTER_CROP
                setImageBitmap(decodeSampled(file, cellSize))
            }
            cell.addView(iv)

            val del = TextView(this).apply {
                text = "×"
                setTextColor(Color.WHITE)
                textSize = 14f
                gravity = Gravity.CENTER
                background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(Color.parseColor("#CC000000"))
                }
                setOnClickListener { removeStagedPhoto(file) }
            }
            cell.addView(del, FrameLayout.LayoutParams(dp(22), dp(22), Gravity.TOP or Gravity.END).apply {
                topMargin = dp(4); rightMargin = dp(4)
            })

            thumbGrid.addView(cell)
        }
    }

    private fun decodeSampled(file: File, target: Int): Bitmap? {
        return try {
            val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(file.absolutePath, opts)
            var sample = 1
            while (opts.outWidth / sample > target * 2) sample *= 2
            val opts2 = BitmapFactory.Options().apply { inSampleSize = sample }
            BitmapFactory.decodeFile(file.absolutePath, opts2)
        } catch (e: Exception) {
            null
        }
    }

    // ---------------- dark mode ----------------

    private fun toggleDarkMode() {
        isDarkMode = !isDarkMode
        applyTheme()
    }

    private fun applyTheme() {
        val bg = if (isDarkMode) Color.parseColor("#121212") else Color.parseColor("#EDEAE3")
        val cardBg = if (isDarkMode) Color.parseColor("#1E1E1E") else Color.WHITE
        val fieldBg = if (isDarkMode) Color.parseColor("#2A2A2A") else Color.parseColor("#F2F0EA")
        val mainText = if (isDarkMode) Color.parseColor("#EFEFEF") else Color.parseColor("#1B1B1B")
        val subText = if (isDarkMode) Color.parseColor("#AAAAAA") else Color.parseColor("#777777")
        val headerBg = Color.parseColor("#1B1B1B") // header คงเข้มเสมอ ให้ contrast กับ tag ส้ม

        rootScroll.setBackgroundColor(bg)
        bodyLayout.setBackgroundColor(bg)
        headerLayout.setBackgroundColor(headerBg)
        card1.background = GradientDrawable().apply { cornerRadius = dp(14).toFloat(); setColor(cardBg) }
        card2.background = GradientDrawable().apply { cornerRadius = dp(14).toFloat(); setColor(cardBg) }

        plateInput.setTextColor(mainText)
        employeeInput.setTextColor(mainText)
        insuranceInput.setTextColor(mainText)
        listOf(plateInput, employeeInput, insuranceInput).forEach {
            it.background = GradientDrawable().apply { cornerRadius = dp(8).toFloat(); setColor(fieldBg) }
        }

        labelTextViews.forEach { it.setTextColor(mainText) }
        cardTextViews.forEach { it.setTextColor(subText) }
        emptyPhotosText.setTextColor(subText)

        confirmButton.setBackgroundColor(if (isDarkMode) Color.parseColor("#3A3A3A") else Color.parseColor("#4A4A4A"))
    }
}
