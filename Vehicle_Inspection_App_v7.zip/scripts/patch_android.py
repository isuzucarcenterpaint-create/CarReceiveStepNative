import re, shutil, sys

PKG = 'com.inspect.vehicleform'

# ---- AndroidManifest: login redirect + camera permission ----
mf = 'android/app/src/main/AndroidManifest.xml'
s = open(mf, encoding='utf-8').read()
if 'oauth2redirect-filter' not in s:
    flt = f'''
        <!-- oauth2redirect-filter -->
        <intent-filter>
            <action android:name="android.intent.action.VIEW" />
            <category android:name="android.intent.category.DEFAULT" />
            <category android:name="android.intent.category.BROWSABLE" />
            <data android:scheme="{PKG}" />
        </intent-filter>
    '''
    s = re.sub(r'<activity(?![^>]*screenOrientation)', '<activity android:screenOrientation="portrait"', s, count=1)
    i = s.find('</activity>')
    if i < 0:
        sys.exit('patch: </activity> not found in AndroidManifest.xml')
    s = s[:i] + flt + s[i:]
    perms = ('    <uses-permission android:name="android.permission.CAMERA" />\n'
             '    <uses-feature android:name="android.hardware.camera" android:required="false" />\n'
             '    <uses-permission android:name="android.permission.VIBRATE" />\n')
    s = s.replace('</manifest>', perms + '</manifest>')
    open(mf, 'w', encoding='utf-8').write(s)
    print('patched manifest')

# ---- Gradle: fixed signing key so the APK signature never changes (read from env / GitHub Secrets) ----
gp = 'android/app/build.gradle'
g = open(gp, encoding='utf-8').read()
if 'signingConfigs.release' not in g:
    shutil.copy('release.p12', 'android/release.p12')
    # passwords come from the build environment (GitHub Secrets); if they are not set the old values are used
    sc = '''    signingConfigs {
        release {
            storeFile file("../release.p12")
            storePassword System.getenv("KS_PASS") ?: "inspect123"
            keyAlias System.getenv("KS_ALIAS") ?: "inspect"
            keyPassword System.getenv("KEY_PASS") ?: "inspect123"
            storeType "pkcs12"
        }
    }
'''
    m = re.search(r'\n([ \t]*)buildTypes\s*\{\s*release\s*\{', g)
    if not m:
        sys.exit('patch: buildTypes { release { not found in app/build.gradle')
    g = g[:m.start() + 1] + sc + g[m.start() + 1:]
    g = re.sub(r'(buildTypes\s*\{\s*release\s*\{)', r'\1\n            signingConfig signingConfigs.release', g, count=1)
    open(gp, 'w', encoding='utf-8').write(g)
    print('patched gradle')

# ---- Native background uploader (WorkManager): sources, manifest, gradle ----
import os
JAVA_DIR = 'android/app/src/main/java/' + PKG.replace('.', '/')
os.makedirs(JAVA_DIR, exist_ok=True)
for fn in ('MainActivity.java', 'UploadQueuePlugin.java', 'UploadWorker.java'):
    shutil.copy('scripts/native/' + fn, JAVA_DIR + '/' + fn)
print('copied native sources to', JAVA_DIR)

s = open(mf, encoding='utf-8').read()
if 'SystemForegroundService' not in s:
    if 'xmlns:tools' not in s:
        if '<manifest ' not in s:
            sys.exit('patch: <manifest ...> tag not found')
        s = s.replace('<manifest ', '<manifest xmlns:tools="http://schemas.android.com/tools" ', 1)
    i = s.find('</application>')
    if i < 0:
        sys.exit('patch: </application> not found in AndroidManifest.xml')
    svc = ('    <service android:name="androidx.work.impl.foreground.SystemForegroundService"\n'
           '        android:foregroundServiceType="dataSync" tools:node="merge" />\n    ')
    s = s[:i] + svc + s[i:]
    perms = ''
    for pm in ('INTERNET', 'FOREGROUND_SERVICE', 'FOREGROUND_SERVICE_DATA_SYNC', 'POST_NOTIFICATIONS', 'REQUEST_IGNORE_BATTERY_OPTIMIZATIONS'):
        if 'android.permission.' + pm + '"' not in s:
            perms += '    <uses-permission android:name="android.permission.' + pm + '" />\n'
    s = s.replace('</manifest>', perms + '</manifest>')
    open(mf, 'w', encoding='utf-8').write(s)
    print('patched manifest for background upload')

g = open(gp, encoding='utf-8').read()
if 'work-runtime' not in g:
    m = re.search(r'\ndependencies\s*\{', g)
    if not m:
        sys.exit('patch: dependencies { not found in app/build.gradle')
    g = g[:m.end()] + '\n    implementation "androidx.work:work-runtime:2.9.1"' + g[m.end():]
    print('added work-runtime dependency')
if 'checkReleaseBuilds' not in g:
    m = re.search(r'\nandroid\s*\{', g)
    if not m:
        sys.exit('patch: android { not found in app/build.gradle')
    g = g[:m.end()] + '\n    lint {\n        abortOnError false\n        checkReleaseBuilds false\n    }' + g[m.end():]
    print('relaxed lint for release build')
open(gp, 'w', encoding='utf-8').write(g)
