module.exports = {
  darkMode: 'class',
  content: ['./www/index.html'],
  theme: {
    extend: {
      fontSize: {
        xs: ['0.6875rem', { lineHeight: '1rem' }],
        sm: ['0.8125rem', { lineHeight: '1.25rem' }],
        base: ['0.9375rem', { lineHeight: '1.4rem' }],
        lg: ['1.0625rem', { lineHeight: '1.6rem' }],
        xl: ['1.1875rem', { lineHeight: '1.7rem' }]
      },
      fontFamily: { sans: ['Prompt', 'sans-serif'] },
      colors: {
        brand: { 50: '#fff7ed', 100: '#ffedd5', 500: '#ff6b00', 600: '#ea580c', 700: '#c2410c' },
        darkbg: '#0d1117', darkcard: '#161b22', darkborder: '#30363d', darkinput: '#21262d'
      }
    }
  }
};
