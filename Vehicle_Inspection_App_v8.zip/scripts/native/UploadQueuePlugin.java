package com.inspect.vehicleform;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Build;
import android.os.PowerManager;
import android.provider.Settings;
import android.util.Base64;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PermissionState;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.getcapacitor.annotation.Permission;
import com.getcapacitor.annotation.PermissionCallback;

import java.io.File;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.Locale;

/**
 * JS -> native bridge. JS stages photos + job.json on disk, then WorkManager (UploadWorker)
 * uploads them to Drive/Sheets even when the screen is locked or the app is closed.
 */
@CapacitorPlugin(name = "UploadQueue", permissions = {
        @Permission(alias = "notifications", strings = { "android.permission.POST_NOTIFICATIONS" })
})
public class UploadQueuePlugin extends Plugin {

    private static boolean validId(String id) {
        return id != null && id.matches("[0-9]{1,20}");
    }

    @PluginMethod
    public void setAuth(PluginCall call) {
        Context c = getContext();
        SharedPreferences sp = UploadWorker.prefs(c);
        String oldRefresh = sp.getString("refresh", "");
        String refresh = call.getString("refreshToken", "");
        SharedPreferences.Editor ed = sp.edit()
                .putString("clientId", call.getString("clientId", ""))
                .putString("refresh", refresh)
                .putString("sheetId", call.getString("sheetId", ""))
                .putString("rootName", call.getString("rootName", "Vehicle Inspection Photos"));
        if (!refresh.equals(oldRefresh)) ed.remove("err");   // new login -> try again
        ed.apply();
        UploadWorker.schedule(c, false);
        call.resolve();
    }

    @PluginMethod
    public void addPhoto(PluginCall call) {
        String id = call.getString("jobId");
        String data = call.getString("data");
        Integer index = call.getInt("index");
        if (!validId(id) || data == null || index == null) { call.reject("bad args"); return; }
        try {
            File dir = new File(UploadWorker.jobsDir(getContext()), id);
            if (!dir.exists() && !dir.mkdirs()) { call.reject("mkdir failed"); return; }
            byte[] bytes = Base64.decode(data, Base64.DEFAULT);
            File f = new File(dir, String.format(Locale.US, "p%03d.jpg", index));
            try (FileOutputStream o = new FileOutputStream(f)) { o.write(bytes); }
            call.resolve();
        } catch (Exception e) {
            call.reject("addPhoto: " + e.getMessage());
        }
    }

    @PluginMethod
    public void commitJob(PluginCall call) {
        String id = call.getString("jobId");
        String meta = call.getString("meta");
        if (!validId(id) || meta == null) { call.reject("bad args"); return; }
        try {
            File dir = new File(UploadWorker.jobsDir(getContext()), id);
            UploadWorker.writeAtomic(new File(dir, "job.json"), meta.getBytes(StandardCharsets.UTF_8));
            UploadWorker.schedule(getContext(), false);
            call.resolve();
        } catch (Exception e) {
            call.reject("commitJob: " + e.getMessage());
        }
    }

    @PluginMethod
    public void discardJob(PluginCall call) {
        String id = call.getString("jobId");
        if (validId(id)) UploadWorker.deleteDir(new File(UploadWorker.jobsDir(getContext()), id));
        call.resolve();
    }

    @PluginMethod
    public void retryNow(PluginCall call) {
        Context c = getContext();
        SharedPreferences sp = UploadWorker.prefs(c);
        sp.edit().remove("err").apply();
        UploadWorker.resetFails(c);                                  // parked jobs become runnable again
        long ts = sp.getLong("progressTs", 0);
        boolean running = !sp.getString("progress", "").isEmpty() && System.currentTimeMillis() - ts < 120000;
        if (!running) UploadWorker.schedule(c, true);
        call.resolve();
    }

    @PluginMethod
    public void status(PluginCall call) {
        Context c = getContext();
        SharedPreferences sp = UploadWorker.prefs(c);
        int pending = UploadWorker.pendingJobs(c).size();
        String err = sp.getString("err", "");
        boolean blocked = err.startsWith("AUTH") || err.startsWith("HTTP");
        if (pending > 0 && !blocked) UploadWorker.schedule(c, false);   // safety net
        long ts = sp.getLong("progressTs", 0);
        String progress = System.currentTimeMillis() - ts < 120000 ? sp.getString("progress", "") : "";
        JSObject r = new JSObject();
        r.put("pending", pending);
        r.put("error", err);
        r.put("progress", progress);
        r.put("parked", UploadWorker.parkedJobs(c));
        r.put("stat", sp.getString("lastStat", ""));
        call.resolve(r);
    }

    // ---------- permissions that keep background upload alive ----------

    /** Android 13+: ask for notification permission (needed to see the progress bar) */
    @PluginMethod
    public void requestNotifications(PluginCall call) {
        if (Build.VERSION.SDK_INT < 33 || getPermissionState("notifications") == PermissionState.GRANTED) {
            JSObject r = new JSObject();
            r.put("granted", true);
            call.resolve(r);
            return;
        }
        requestPermissionForAlias("notifications", call, "notifResult");
    }

    @PermissionCallback
    private void notifResult(PluginCall call) {
        JSObject r = new JSObject();
        r.put("granted", getPermissionState("notifications") == PermissionState.GRANTED);
        call.resolve(r);
    }

    /** asks the system to exempt the app from battery saving (MagicOS / other brands kill background work) */
    @PluginMethod
    public void requestIgnoreBattery(PluginCall call) {
        Context c = getContext();
        boolean ignoring = true;
        try {
            if (Build.VERSION.SDK_INT >= 23) {
                PowerManager pm = (PowerManager) c.getSystemService(Context.POWER_SERVICE);
                ignoring = pm == null || pm.isIgnoringBatteryOptimizations(c.getPackageName());
                if (!ignoring) {
                    try {
                        Intent i = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                                Uri.parse("package:" + c.getPackageName()));
                        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        c.startActivity(i);
                    } catch (Exception e) {
                        Intent i = new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS);
                        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        c.startActivity(i);
                    }
                }
            }
        } catch (Exception ignored) { }
        JSObject r = new JSObject();
        r.put("ignoring", ignoring);
        call.resolve(r);
    }

    /** opens this app's system settings page (auto-start / background switches on Honor, Huawei, etc.) */
    @PluginMethod
    public void openAppSettings(PluginCall call) {
        try {
            Context c = getContext();
            Intent i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + c.getPackageName()));
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            c.startActivity(i);
        } catch (Exception ignored) { }
        call.resolve();
    }
}
