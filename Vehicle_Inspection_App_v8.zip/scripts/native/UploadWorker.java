package com.inspect.vehicleform;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.SystemClock;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.core.app.NotificationCompat;
import androidx.work.BackoffPolicy;
import androidx.work.Constraints;
import androidx.work.ExistingWorkPolicy;
import androidx.work.ForegroundInfo;
import androidx.work.NetworkType;
import androidx.work.OneTimeWorkRequest;
import androidx.work.OutOfQuotaPolicy;
import androidx.work.WorkManager;
import androidx.work.Worker;
import androidx.work.WorkerParameters;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.SocketTimeoutException;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.atomic.AtomicReference;

/**
 * Uploads queued inspection jobs (photos -> Drive folder, row -> Google Sheet) in the background.
 * Job layout: files/jobs/<id>/job.json + p000.jpg, p001.jpg ...
 *
 * - photos go up 4 at a time (drops to 2 / 1 automatically when the network keeps timing out)
 * - each photo is tried 3 times; before a retry Drive is checked so a photo is never uploaded twice
 * - a job that fails is parked and the queue moves on to the next job
 * - local photos are deleted only after the whole job (photos + sheet row) is done
 */
public class UploadWorker extends Worker {

    static final String UNIQUE = "vif-upload";
    static final String CHANNEL = "vif_upload";
    static final int NOTIF_ID = 4711;
    static final String TAG = "VIF";

    static final int PARALLEL = 4;          // photos in flight at once
    static final int PHOTO_TRIES = 3;       // attempts per photo before the job is parked
    static final int MAX_JOB_FAILS = 3;     // failed runs before a job waits for the user's "retry"

    private long lastNotifMs = 0;

    public UploadWorker(@NonNull Context context, @NonNull WorkerParameters params) {
        super(context, params);
    }

    // ---------- shared helpers ----------
    static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences("vif_native", Context.MODE_PRIVATE);
    }

    static File jobsDir(Context c) {
        File d = new File(c.getFilesDir(), "jobs");
        if (!d.exists()) d.mkdirs();
        return d;
    }

    /** committed jobs only (a directory without job.json is still being staged), oldest first */
    static List<File> pendingJobs(Context c) {
        List<File> out = new ArrayList<>();
        File[] dirs = jobsDir(c).listFiles();
        if (dirs == null) return out;
        for (File d : dirs) {
            if (d.isDirectory() && new File(d, "job.json").exists()) out.add(d);
        }
        Collections.sort(out, (a, b) -> {
            try { return Long.compare(Long.parseLong(a.getName()), Long.parseLong(b.getName())); }
            catch (NumberFormatException e) { return a.getName().compareTo(b.getName()); }
        });
        return out;
    }

    static void writeAtomic(File f, byte[] bytes) throws IOException {
        File tmp = new File(f.getParentFile(), f.getName() + ".tmp");
        try (FileOutputStream o = new FileOutputStream(tmp)) { o.write(bytes); o.getFD().sync(); }
        if (!tmp.renameTo(f)) {
            if (f.exists()) f.delete();
            if (!tmp.renameTo(f)) throw new IOException("rename failed");
        }
    }

    static void deleteDir(File d) {
        File[] kids = d.listFiles();
        if (kids != null) for (File k : kids) { if (k.isDirectory()) deleteDir(k); else k.delete(); }
        d.delete();
    }

    static byte[] readFile(File f) throws IOException {
        try (InputStream in = new FileInputStream(f)) { return readBytes(in); }
    }

    static byte[] readBytes(InputStream in) throws IOException {
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        byte[] buf = new byte[16384];
        int n;
        while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
        return bo.toByteArray();
    }

    static String md5Hex(byte[] b) throws Exception {
        byte[] d = MessageDigest.getInstance("MD5").digest(b);
        StringBuilder sb = new StringBuilder();
        for (byte x : d) sb.append(String.format(Locale.US, "%02x", x & 0xff));
        return sb.toString();
    }

    static JSONObject readJob(File dir) throws Exception {
        return new JSONObject(new String(readFile(new File(dir, "job.json")), StandardCharsets.UTF_8));
    }

    static int jobFails(File dir) {
        try { return readJob(dir).optInt("fails", 0); } catch (Exception e) { return 0; }
    }

    /** remember a failed run on the job itself (survives app restarts) */
    static void markFail(File dir, String msg) {
        try {
            JSONObject j = readJob(dir);
            j.put("fails", j.optInt("fails", 0) + 1);
            j.put("lastErr", msg == null ? "" : msg);
            writeAtomic(new File(dir, "job.json"), j.toString().getBytes(StandardCharsets.UTF_8));
        } catch (Exception ignored) { }
    }

    /** user tapped "retry": parked jobs become runnable again */
    static void resetFails(Context c) {
        for (File d : pendingJobs(c)) {
            try {
                JSONObject j = readJob(d);
                if (j.optInt("fails", 0) > 0 || j.has("lastErr")) {
                    j.put("fails", 0);
                    j.remove("lastErr");
                    writeAtomic(new File(d, "job.json"), j.toString().getBytes(StandardCharsets.UTF_8));
                }
            } catch (Exception ignored) { }
        }
    }

    static int parkedJobs(Context c) {
        int n = 0;
        for (File d : pendingJobs(c)) if (jobFails(d) >= MAX_JOB_FAILS) n++;
        return n;
    }

    static void schedule(Context c, boolean replace) {
        if (pendingJobs(c).isEmpty()) return;
        Constraints cons = new Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build();
        OneTimeWorkRequest req = new OneTimeWorkRequest.Builder(UploadWorker.class)
                .setConstraints(cons)
                .setExpedited(OutOfQuotaPolicy.RUN_AS_NON_EXPEDITED_WORK_REQUEST)
                .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 15, TimeUnit.SECONDS)
                .build();
        WorkManager.getInstance(c).enqueueUniqueWork(UNIQUE,
                replace ? ExistingWorkPolicy.REPLACE : ExistingWorkPolicy.KEEP, req);
    }

    // ---------- progress + notification ----------
    private void progress(SharedPreferences sp, String text, int done, int total) {
        sp.edit().putString("progress", text).putLong("progressTs", System.currentTimeMillis()).apply();
        long now = SystemClock.elapsedRealtime();
        if (total <= 0 || done >= total || now - lastNotifMs > 800) {
            lastNotifMs = now;
            try { setForegroundAsync(fgInfo(buildNotif(text, done, total))); } catch (Exception ignored) { }
        }
    }

    private static void ensureChannel(Context c) {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel(CHANNEL, "ส่งรูปตรวจสภาพรถ", NotificationManager.IMPORTANCE_LOW);
            NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm != null) nm.createNotificationChannel(ch);
        }
    }

    private Notification buildNotif(String text, int done, int total) {
        Context c = getApplicationContext();
        ensureChannel(c);
        NotificationCompat.Builder b = new NotificationCompat.Builder(c, CHANNEL)
                .setContentTitle("กำลังส่งรูปตรวจสภาพรถ")
                .setContentText(text)
                .setSmallIcon(android.R.drawable.stat_sys_upload)
                .setOngoing(true)
                .setOnlyAlertOnce(true);
        if (total > 0) b.setProgress(total, Math.min(done, total), false);
        else b.setProgress(0, 0, true);
        Intent li = c.getPackageManager().getLaunchIntentForPackage(c.getPackageName());
        if (li != null) {
            int fl = PendingIntent.FLAG_UPDATE_CURRENT;
            if (Build.VERSION.SDK_INT >= 23) fl |= PendingIntent.FLAG_IMMUTABLE;
            b.setContentIntent(PendingIntent.getActivity(c, 0, li, fl));
        }
        return b.build();
    }

    private static ForegroundInfo fgInfo(Notification n) {
        if (Build.VERSION.SDK_INT >= 29) {
            return new ForegroundInfo(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC);
        }
        return new ForegroundInfo(NOTIF_ID, n);
    }

    // needed for expedited work on Android < 12
    @NonNull
    @Override
    public ForegroundInfo getForegroundInfo() {
        return fgInfo(buildNotif("กำลังส่งขึ้น Google Drive / Sheet เบื้องหลัง", 0, 0));
    }

    // ---------- errors ----------
    static class AuthException extends Exception {
        AuthException(String m) { super(m); }
    }

    static class HttpException extends Exception {
        final int code;
        final String resp;
        HttpException(int code, String m) { this(code, m, ""); }
        HttpException(int code, String m, String resp) { super(m); this.code = code; this.resp = resp == null ? "" : resp; }
    }

    /** worth trying again later: rate limit, server trouble */
    static boolean isTransient(HttpException e) {
        String m = String.valueOf(e.getMessage()) + " " + e.resp;
        return e.code == 429 || e.code >= 500 || m.contains("ateLimit") || m.contains("Rate Limit") || m.contains("backendError");
    }

    // ---------- main work ----------
    @NonNull
    @Override
    public Result doWork() {
        Context c = getApplicationContext();
        SharedPreferences sp = prefs(c);
        if (pendingJobs(c).isEmpty()) return Result.success();

        String clientId = sp.getString("clientId", "");
        String refresh = sp.getString("refresh", "");
        String sheetId = sp.getString("sheetId", "");
        if (clientId.isEmpty() || refresh.isEmpty() || sheetId.isEmpty()) {
            sp.edit().putString("err", "AUTH:ยังไม่ได้ล็อกอิน Google").apply();
            return Result.failure();
        }
        try { setForegroundAsync(getForegroundInfo()); } catch (Exception ignored) { }
        String failMsg = null;
        Set<String> skipped = new HashSet<>();
        try {
            progress(sp, "เริ่มส่ง...", 0, 0);
            Api api = new Api(clientId, refresh);
            while (!isStopped()) {
                File next = null;
                for (File d : pendingJobs(c)) {
                    if (skipped.contains(d.getName())) continue;
                    if (jobFails(d) >= MAX_JOB_FAILS) continue;
                    next = d;
                    break;
                }
                if (next == null) break;
                try {
                    processJob(api, next, sheetId, sp);
                } catch (AuthException e) {
                    throw e;
                } catch (HttpException e) {
                    markFail(next, e.getMessage());
                    if (isTransient(e)) throw e;               // Drive is busy: wait and retry the whole run
                    skipped.add(next.getName());               // this job is broken: park it, send the others
                    failMsg = String.valueOf(e.getMessage());
                } catch (IOException e) {
                    throw e;                                   // network trouble: stop, WorkManager retries
                } catch (Exception e) {
                    String m = e.getClass().getSimpleName() + " " + e.getMessage();
                    markFail(next, m);
                    skipped.add(next.getName());
                    failMsg = m;
                }
            }
            if (isStopped()) return Result.retry();
            if (failMsg == null && parkedJobs(c) > 0) {
                String old = sp.getString("err", "");
                failMsg = old.startsWith("HTTP:") ? old.substring(5) : "มีงานที่ส่งไม่สำเร็จ";
            }
            if (failMsg != null) {
                sp.edit().putString("err", "HTTP:" + failMsg).apply();
                return Result.failure();
            }
            sp.edit().remove("err").apply();
            return Result.success();
        } catch (AuthException e) {
            sp.edit().putString("err", "AUTH:" + e.getMessage()).apply();
            return Result.failure();
        } catch (HttpException e) {
            sp.edit().putString("err", "NET:" + e.getMessage()).apply();
            return Result.retry();
        } catch (IOException e) {
            sp.edit().putString("err", "NET:" + e.getClass().getSimpleName()).apply();
            return Result.retry();
        } catch (Exception e) {
            sp.edit().putString("err", "HTTP:" + e.getClass().getSimpleName() + " " + e.getMessage()).apply();
            return Result.failure();
        } finally {
            sp.edit().remove("progress").apply();
        }
    }

    private void processJob(Api api, File dir, String sheetId, SharedPreferences sp) throws Exception {
        File jf = new File(dir, "job.json");
        JSONObject job = readJob(dir);
        JSONArray names = job.getJSONArray("fileNames");
        JSONArray row = job.getJSONArray("row");
        String label = row.length() > 2 ? row.optString(2, "") : "";
        int total = names.length();
        Object lock = new Object();

        boolean recreated = false;
        while (true) {
            if (isStopped()) return;
            String folderId = prepareFolder(api, job, jf, sp, label);
            try {
                Batch b = new Batch(api, dir, jf, job, lock, names, total, folderId, label, sp);
                if (!b.run()) return;                           // stopped half way: resume later
                break;
            } catch (HttpException e) {
                if (e.code == 404 && !recreated) {              // Drive folder was deleted: build it again, resend all
                    recreated = true;
                    synchronized (lock) {
                        job.remove("folderId");
                        job.remove("folderLink");
                        job.remove("doneIdx");
                        job.put("uploaded", 0);
                        writeAtomic(jf, job.toString().getBytes(StandardCharsets.UTF_8));
                    }
                    continue;
                }
                throw e;
            }
        }

        if (!job.optBoolean("rowDone", false)) {
            progress(sp, label + ": บันทึกลงชีท", total, total);
            JSONArray full = new JSONArray();
            for (int i = 0; i < row.length(); i++) full.put(row.get(i));
            full.put(job.optString("folderLink", ""));
            api.appendRow(sp, sheetId, job.getJSONArray("header"), full);
            job.put("rowDone", true);
            writeAtomic(jf, job.toString().getBytes(StandardCharsets.UTF_8));
        }
        deleteDir(dir);                                         // only now are the local photos removed
    }

    /** returns a Drive folder id that exists (creates / re-creates it when needed) */
    private String prepareFolder(Api api, JSONObject job, File jf, SharedPreferences sp, String label) throws Exception {
        String folderId = job.optString("folderId", "");
        if (!folderId.isEmpty()) {
            try {
                JSONObject info = api.folderInfo(folderId);
                if (info.optBoolean("trashed", false)) folderId = "";
            } catch (HttpException e) {
                if (e.code == 404) folderId = ""; else throw e;
            }
            if (folderId.isEmpty()) {                           // folder was deleted or trashed
                job.remove("folderId");
                job.remove("folderLink");
                job.remove("doneIdx");
                job.put("uploaded", 0);
                writeAtomic(jf, job.toString().getBytes(StandardCharsets.UTF_8));
            }
        }
        if (folderId.isEmpty()) {
            progress(sp, label + ": เตรียมโฟลเดอร์", 0, 0);
            String rootName = sp.getString("rootName", "Vehicle Inspection Photos");
            String[] root = api.findOrCreate(rootName, null);
            String[] car = api.findOrCreate(job.getString("folderName"), root[0]);
            job.put("folderId", car[0]);
            job.put("folderLink", car[1]);
            writeAtomic(jf, job.toString().getBytes(StandardCharsets.UTF_8));
            folderId = car[0];
        }
        return folderId;
    }

    /** slows down when the network keeps timing out, speeds up again when it recovers */
    static class Throttle {
        final AtomicInteger limit = new AtomicInteger(PARALLEL);
        private int timeouts = 0, ok = 0;

        synchronized void onTimeout() {
            ok = 0;
            timeouts++;
            if (timeouts >= 2 && limit.get() > 1) {
                limit.set(Math.max(1, limit.get() / 2));
                timeouts = 0;
            }
        }

        synchronized void onSuccess() {
            timeouts = 0;
            ok++;
            if (ok >= 8 && limit.get() < PARALLEL) {
                limit.incrementAndGet();
                ok = 0;
            }
        }
    }

    /** uploads every photo of one job that is not on Drive yet */
    class Batch {
        final Api api;
        final File dir, jf;
        final JSONObject job;
        final Object lock;
        final JSONArray names;
        final int total;
        final String folderId, label;
        final SharedPreferences sp;
        final Set<Integer> done = Collections.synchronizedSet(new HashSet<Integer>());
        final ConcurrentLinkedQueue<Integer> todo = new ConcurrentLinkedQueue<>();
        final AtomicReference<Exception> firstErr = new AtomicReference<>();
        final AtomicBoolean abort = new AtomicBoolean(false);
        final AtomicLong photoMs = new AtomicLong(0);
        final Throttle th = new Throttle();
        final Random rnd = new Random();
        Map<String, List<String[]>> existing = new HashMap<>();

        Batch(Api api, File dir, File jf, JSONObject job, Object lock, JSONArray names, int total,
              String folderId, String label, SharedPreferences sp) {
            this.api = api; this.dir = dir; this.jf = jf; this.job = job; this.lock = lock;
            this.names = names; this.total = total; this.folderId = folderId; this.label = label; this.sp = sp;
        }

        /** true = every photo is on Drive; false = stopped early; throws when a photo failed for good */
        boolean run() throws Exception {
            synchronized (lock) {
                int prefix = job.optInt("uploaded", 0);          // older versions counted in order
                for (int i = 0; i < prefix && i < total; i++) done.add(i);
                JSONArray di = job.optJSONArray("doneIdx");
                if (di != null) for (int i = 0; i < di.length(); i++) done.add(di.getInt(i));
            }
            if (done.size() >= total) return true;

            existing = api.listFolder(folderId);                 // what is already in the folder (one call)
            for (int i = 0; i < total; i++) if (!done.contains(i)) todo.add(i);
            final int startDone = done.size();
            final long t0 = SystemClock.elapsedRealtime();
            progress(sp, label + ": อัปโหลดรูป " + startDone + "/" + total, startDone, total);

            ExecutorService pool = Executors.newFixedThreadPool(PARALLEL);
            for (int w = 0; w < PARALLEL; w++) {
                final int id = w;
                pool.submit(new Runnable() {
                    @Override public void run() { worker(id); }
                });
            }
            pool.shutdown();
            try {
                while (!pool.awaitTermination(500, TimeUnit.MILLISECONDS)) {
                    if (isStopped()) abort.set(true);
                }
            } catch (InterruptedException ie) {
                abort.set(true);
                pool.shutdownNow();
                Thread.currentThread().interrupt();
            }

            Exception e = firstErr.get();
            if (e != null) throw e;
            if (done.size() < total) return false;

            int n = done.size() - startDone;
            if (n > 0) {
                long sec = (SystemClock.elapsedRealtime() - t0) / 1000;
                String stat = "ส่ง " + n + " รูป ใน " + sec + " วินาที (เฉลี่ย "
                        + String.format(Locale.US, "%.1f", photoMs.get() / 1000.0 / n) + " วินาที/รูป, ขนาน "
                        + th.limit.get() + ")";
                Log.i(TAG, label + ": " + stat);
                sp.edit().putString("lastStat", stat).apply();
            }
            return true;
        }

        void worker(int id) {
            while (!abort.get() && !isStopped()) {
                if (id >= th.limit.get()) {                      // this lane is switched off for now
                    if (todo.isEmpty()) return;
                    try { Thread.sleep(300); } catch (InterruptedException e) { return; }
                    continue;
                }
                Integer idx = todo.poll();
                if (idx == null) return;
                try {
                    uploadOne(idx);
                } catch (Exception e) {
                    firstErr.compareAndSet(null, e);
                    abort.set(true);
                    return;
                }
            }
        }

        void uploadOne(int i) throws Exception {
            long t = SystemClock.elapsedRealtime();
            File f = new File(dir, String.format(Locale.US, "p%03d.jpg", i));
            if (!f.exists()) throw new HttpException(0, "ไฟล์รูปหาย " + f.getName());
            byte[] img = readFile(f);
            String name = names.getString(i);
            String md5 = md5Hex(img);
            boolean onDrive = false;
            List<String[]> ex = existing.get(name);
            if (ex != null) for (String[] e : ex) if (md5.equalsIgnoreCase(e[1])) onDrive = true;
            if (!onDrive) uploadWithRetry(name, img, md5);
            photoMs.addAndGet(SystemClock.elapsedRealtime() - t);
            markDone(i);
        }

        void uploadWithRetry(String name, byte[] img, String md5) throws Exception {
            Exception last = null;
            for (int attempt = 0; attempt < PHOTO_TRIES; attempt++) {
                if (abort.get() || isStopped()) throw new IOException("stopped");
                try {
                    // an earlier try may have reached Drive even though we saw an error: look before sending again
                    if (attempt > 0 && api.hasFile(name, folderId, md5)) { th.onSuccess(); return; }
                    api.uploadJpeg(name, folderId, img);
                    th.onSuccess();
                    return;
                } catch (AuthException e) {
                    throw e;
                } catch (HttpException e) {
                    if (!isTransient(e)) throw e;
                    last = e;
                    pause(attempt, e.code == 429 || String.valueOf(e.resp).contains("ateLimit"));
                } catch (IOException e) {
                    last = e;
                    if (e instanceof SocketTimeoutException) th.onTimeout();
                    pause(attempt, false);
                }
            }
            throw last != null ? last : new IOException("upload failed");
        }

        void pause(int attempt, boolean rateLimited) throws IOException {
            if (attempt >= PHOTO_TRIES - 1) return;              // last try: no point waiting
            long ms = ((rateLimited ? 3000L : 1000L) << attempt) + rnd.nextInt(500);
            try { Thread.sleep(ms); }
            catch (InterruptedException e) { Thread.currentThread().interrupt(); throw new IOException("stopped"); }
        }

        void markDone(int i) throws Exception {
            done.add(i);
            int d = done.size();
            synchronized (lock) {
                JSONArray a = new JSONArray();
                synchronized (done) { for (Integer x : done) a.put(x.intValue()); }
                job.put("doneIdx", a);
                writeAtomic(jf, job.toString().getBytes(StandardCharsets.UTF_8));
            }
            progress(sp, label + ": อัปโหลดรูป " + d + "/" + total, d, total);
        }
    }

    // ---------- Google REST (HttpURLConnection, no extra libraries) ----------
    static class Api {
        final String clientId, refresh;
        private String access;
        private long exp;

        Api(String clientId, String refresh) {
            this.clientId = clientId;
            this.refresh = refresh;
        }

        static HttpURLConnection open(String url, String method) throws IOException {
            HttpURLConnection h = (HttpURLConnection) new URL(url).openConnection();
            h.setRequestMethod(method);
            h.setConnectTimeout(15000);     // short: a dead network is noticed quickly
            h.setReadTimeout(120000);       // long: a slow network still gets a full photo through
            return h;
        }

        /** reads the whole answer and closes the stream, so the connection can be reused (keep-alive) */
        static String body(HttpURLConnection h, int code) throws IOException {
            InputStream in = code >= 400 ? h.getErrorStream() : h.getInputStream();
            if (in == null) return "";
            try {
                return new String(readBytes(in), StandardCharsets.UTF_8);
            } finally {
                try { in.close(); } catch (IOException ignored) { }
            }
        }

        static String esc(String s) {
            return s.replace("\\", "\\\\").replace("'", "\\'");
        }

        static String enc(String s) throws IOException {
            return URLEncoder.encode(s, "UTF-8");
        }

        private synchronized String ensureAccess() throws Exception {
            if (access == null || System.currentTimeMillis() > exp - 60000) refreshAccess();
            return access;
        }

        private synchronized void invalidate(String used) {
            if (used != null && used.equals(access)) access = null;
        }

        private void refreshAccess() throws Exception {
            byte[] b = ("grant_type=refresh_token&refresh_token=" + enc(refresh)
                    + "&client_id=" + enc(clientId)).getBytes(StandardCharsets.UTF_8);
            HttpURLConnection h = open("https://oauth2.googleapis.com/token", "POST");
            h.setDoOutput(true);
            h.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
            h.setFixedLengthStreamingMode(b.length);
            int code;
            String resp;
            try {
                try (OutputStream o = h.getOutputStream()) { o.write(b); }
                code = h.getResponseCode();
                resp = body(h, code);
            } catch (IOException e) {
                h.disconnect();
                throw e;
            }
            if (code >= 400) {
                if (resp.contains("invalid_grant") || resp.contains("invalid_client") || resp.contains("unauthorized_client")) {
                    throw new AuthException("ต้องล็อกอิน Google ใหม่");
                }
                throw new HttpException(code, "token " + code, resp);
            }
            JSONObject j = new JSONObject(resp);
            access = j.getString("access_token");
            exp = System.currentTimeMillis() + j.optLong("expires_in", 3600) * 1000L;
        }

        /** safe to call from several threads at once */
        String call(String method, String url, String ctype, byte[] payload) throws Exception {
            for (int attempt = 0; attempt < 2; attempt++) {
                String tok = ensureAccess();
                HttpURLConnection h = open(url, method);
                int code;
                String resp;
                try {
                    h.setRequestProperty("Authorization", "Bearer " + tok);
                    if (ctype != null) h.setRequestProperty("Content-Type", ctype);
                    if (payload != null) {
                        h.setDoOutput(true);
                        h.setFixedLengthStreamingMode(payload.length);
                        try (OutputStream o = h.getOutputStream()) { o.write(payload); }
                    }
                    code = h.getResponseCode();
                    resp = body(h, code);
                } catch (IOException e) {
                    h.disconnect();                              // only a broken connection is closed
                    throw e;
                }
                if (code == 401) {
                    if (attempt == 0) { invalidate(tok); continue; }
                    throw new AuthException("ต้องล็อกอิน Google ใหม่");
                }
                if (code >= 400) {
                    throw new HttpException(code, code + " " + (resp.length() > 160 ? resp.substring(0, 160) : resp), resp);
                }
                return resp;
            }
            throw new HttpException(0, "unreachable");
        }

        String[] findOrCreate(String name, String parent) throws Exception {
            String q = "name='" + esc(name) + "' and mimeType='application/vnd.google-apps.folder' and trashed=false";
            if (parent != null) q += " and '" + parent + "' in parents";
            String r = call("GET", "https://www.googleapis.com/drive/v3/files?fields="
                    + enc("files(id,webViewLink)") + "&q=" + enc(q), null, null);
            JSONArray a = new JSONObject(r).optJSONArray("files");
            if (a != null && a.length() > 0) {
                JSONObject f = a.getJSONObject(0);
                return new String[]{f.getString("id"), f.optString("webViewLink", "")};
            }
            JSONObject b = new JSONObject();
            b.put("name", name);
            b.put("mimeType", "application/vnd.google-apps.folder");
            if (parent != null) b.put("parents", new JSONArray().put(parent));
            String c = call("POST", "https://www.googleapis.com/drive/v3/files?fields="
                    + enc("id,webViewLink"), "application/json; charset=UTF-8",
                    b.toString().getBytes(StandardCharsets.UTF_8));
            JSONObject f = new JSONObject(c);
            return new String[]{f.getString("id"), f.optString("webViewLink", "")};
        }

        /** 404 = folder is gone; "trashed":true = in the bin */
        JSONObject folderInfo(String id) throws Exception {
            String r = call("GET", "https://www.googleapis.com/drive/v3/files/" + enc(id)
                    + "?fields=" + enc("id,trashed,webViewLink"), null, null);
            return new JSONObject(r);
        }

        /** name -> [id, md5] of everything inside the folder */
        Map<String, List<String[]>> listFolder(String folderId) throws Exception {
            Map<String, List<String[]>> m = new HashMap<>();
            String page = null;
            do {
                String q = "'" + folderId + "' in parents and trashed=false";
                String url = "https://www.googleapis.com/drive/v3/files?pageSize=1000&fields="
                        + enc("nextPageToken,files(id,name,md5Checksum)") + "&q=" + enc(q);
                if (page != null) url += "&pageToken=" + enc(page);
                JSONObject o = new JSONObject(call("GET", url, null, null));
                JSONArray a = o.optJSONArray("files");
                if (a != null) {
                    for (int i = 0; i < a.length(); i++) {
                        JSONObject f = a.getJSONObject(i);
                        String n = f.optString("name", "");
                        List<String[]> l = m.get(n);
                        if (l == null) { l = new ArrayList<>(); m.put(n, l); }
                        l.add(new String[]{f.optString("id", ""), f.optString("md5Checksum", "")});
                    }
                }
                page = o.has("nextPageToken") ? o.getString("nextPageToken") : null;
            } while (page != null);
            return m;
        }

        /** is a file with this name AND identical content already in the folder? */
        boolean hasFile(String name, String folderId, String md5) throws Exception {
            String q = "name='" + esc(name) + "' and '" + folderId + "' in parents and trashed=false";
            String r = call("GET", "https://www.googleapis.com/drive/v3/files?fields="
                    + enc("files(id,md5Checksum)") + "&q=" + enc(q), null, null);
            JSONArray a = new JSONObject(r).optJSONArray("files");
            if (a != null) {
                for (int i = 0; i < a.length(); i++) {
                    if (md5.equalsIgnoreCase(a.getJSONObject(i).optString("md5Checksum", ""))) return true;
                }
            }
            return false;
        }

        void uploadJpeg(String name, String folderId, byte[] img) throws Exception {
            String boundary = "vif" + System.nanoTime();
            JSONObject meta = new JSONObject();
            meta.put("name", name);
            meta.put("parents", new JSONArray().put(folderId));
            ByteArrayOutputStream bo = new ByteArrayOutputStream(img.length + 1024);
            bo.write(("--" + boundary + "\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n").getBytes(StandardCharsets.UTF_8));
            bo.write(meta.toString().getBytes(StandardCharsets.UTF_8));
            bo.write(("\r\n--" + boundary + "\r\nContent-Type: image/jpeg\r\n\r\n").getBytes(StandardCharsets.UTF_8));
            bo.write(img);
            bo.write(("\r\n--" + boundary + "--").getBytes(StandardCharsets.UTF_8));
            call("POST", "https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart&fields=id",
                    "multipart/related; boundary=" + boundary, bo.toByteArray());
        }

        String sheetTitle(SharedPreferences sp, String sheetId) throws Exception {
            String t = sp.getString("sheetTitle", "");
            if (!t.isEmpty() && sheetId.equals(sp.getString("sheetFor", ""))) return t;
            String r = call("GET", "https://sheets.googleapis.com/v4/spreadsheets/" + sheetId + "?fields="
                    + enc("sheets.properties.title"), null, null);
            t = new JSONObject(r).getJSONArray("sheets").getJSONObject(0).getJSONObject("properties").getString("title");
            sp.edit().putString("sheetTitle", t).putString("sheetFor", sheetId).apply();
            return t;
        }

        void appendRow(SharedPreferences sp, String sheetId, JSONArray header, JSONArray row) throws Exception {
            String t = sheetTitle(sp, sheetId);
            String rng = enc("'" + t.replace("'", "''") + "'!A1").replace("+", "%20");
            String base = "https://sheets.googleapis.com/v4/spreadsheets/" + sheetId + "/values/" + rng;
            try {
                String h = call("GET", base, null, null);
                JSONArray values = new JSONArray();
                if (!new JSONObject(h).has("values")) values.put(header);
                values.put(row);
                JSONObject body = new JSONObject();
                body.put("values", values);
                call("POST", base + ":append?valueInputOption=USER_ENTERED&insertDataOption=INSERT_ROWS",
                        "application/json; charset=UTF-8", body.toString().getBytes(StandardCharsets.UTF_8));
            } catch (HttpException e) {
                if (e.code == 400) sp.edit().remove("sheetTitle").remove("sheetFor").apply();   // tab renamed?
                throw e;
            }
        }
    }
}
